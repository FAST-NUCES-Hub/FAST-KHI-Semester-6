"""
RetroCalc Compiler - Three-Address Code Generator
Translates the AST into a flat list of Three-Address Code (TAC) instructions.
"""

from dataclasses import dataclass
from typing import Any, List, Optional

from ast_nodes import (
    Program, LetStatement, PrintStatement, IfStatement, LoopStatement,
    BinaryOp, UnaryOp, NumberLiteral, Identifier,
)


@dataclass
class TACInstruction:
    """
    A single Three-Address Code instruction.

    Forms:
        ASSIGN:     result = arg1
        BINARY_OP:  result = arg1 op arg2
        UNARY_OP:   result = op arg1
        PRINT:      PRINT arg1
        LABEL:      LABEL arg1
        GOTO:       GOTO arg1
        IF_FALSE:   IF_FALSE arg1 GOTO arg2
    """
    op: str
    arg1: Any = None
    arg2: Any = None
    result: Any = None

    def __repr__(self):
        if self.op == "ASSIGN":
            return f"  {self.result} = {self.arg1}"
        elif self.op in ("+", "-", "*", "/", "%", ">", "<", ">=", "<=", "==", "!="):
            return f"  {self.result} = {self.arg1} {self.op} {self.arg2}"
        elif self.op == "UNARY_MINUS":
            return f"  {self.result} = -{self.arg1}"
        elif self.op == "PRINT":
            return f"  PRINT {self.arg1}"
        elif self.op == "LABEL":
            return f"{self.arg1}:"
        elif self.op == "GOTO":
            return f"  GOTO {self.arg1}"
        elif self.op == "IF_FALSE":
            return f"  IF_FALSE {self.arg1} GOTO {self.arg2}"
        else:
            return f"  {self.op}({self.arg1}, {self.arg2}) -> {self.result}"


class TACGenerator:
    """
    Walks the AST and emits Three-Address Code instructions.
    """

    def __init__(self):
        self.instructions: List[TACInstruction] = []
        self._temp_counter = 0
        self._label_counter = 0

    def _new_temp(self) -> str:
        """Generate a fresh temporary variable name."""
        name = f"t{self._temp_counter}"
        self._temp_counter += 1
        return name

    def _new_label(self) -> str:
        """Generate a fresh label name."""
        name = f"L{self._label_counter}"
        self._label_counter += 1
        return name

    def _emit(self, op, arg1=None, arg2=None, result=None):
        """Append a TAC instruction."""
        self.instructions.append(TACInstruction(op=op, arg1=arg1, arg2=arg2, result=result))

    def generate(self, ast: Program) -> List[TACInstruction]:
        """
        Generate TAC from the AST.

        Args:
            ast: The root Program node.

        Returns:
            list[TACInstruction]: The generated TAC instruction list.
        """
        self.instructions = []
        self._temp_counter = 0
        self._label_counter = 0

        for stmt in ast.statements:
            self._gen_statement(stmt)

        return self.instructions

    # ─── Statement Generation ─────────────────────────────────────────────

    def _gen_statement(self, stmt):
        """Generate TAC for a single statement."""
        if isinstance(stmt, LetStatement):
            self._gen_let(stmt)
        elif isinstance(stmt, PrintStatement):
            self._gen_print(stmt)
        elif isinstance(stmt, IfStatement):
            self._gen_if(stmt)
        elif isinstance(stmt, LoopStatement):
            self._gen_loop(stmt)

    def _gen_let(self, stmt: LetStatement):
        """Generate TAC for: let <name> = <expr>"""
        result = self._gen_expression(stmt.expression)
        self._emit("ASSIGN", arg1=result, result=stmt.name)

    def _gen_print(self, stmt: PrintStatement):
        """Generate TAC for: print <expr>"""
        result = self._gen_expression(stmt.expression)
        self._emit("PRINT", arg1=result)

    def _gen_if(self, stmt: IfStatement):
        """
        Generate TAC for: if <cond> ... end

        Emits:
            <cond code>
            IF_FALSE cond_result GOTO L_end
            <body code>
            LABEL L_end
        """
        cond_result = self._gen_expression(stmt.condition)
        label_end = self._new_label()

        self._emit("IF_FALSE", arg1=cond_result, arg2=label_end)

        for body_stmt in stmt.body:
            self._gen_statement(body_stmt)

        self._emit("LABEL", arg1=label_end)

    def _gen_loop(self, stmt: LoopStatement):
        """
        Generate TAC for: loop <count> ... end

        Emits:
            counter = 0
            limit = <count>
            LABEL L_start
            cond = counter < limit
            IF_FALSE cond GOTO L_end
            <body code>
            counter = counter + 1
            GOTO L_start
            LABEL L_end
        """
        # Evaluate the loop count
        limit = self._gen_expression(stmt.count)
        counter = self._new_temp()
        label_start = self._new_label()
        label_end = self._new_label()

        # Initialize counter
        self._emit("ASSIGN", arg1=0, result=counter)

        # Loop start label
        self._emit("LABEL", arg1=label_start)

        # Check condition: counter < limit
        cond = self._new_temp()
        self._emit("<", arg1=counter, arg2=limit, result=cond)
        self._emit("IF_FALSE", arg1=cond, arg2=label_end)

        # Body
        for body_stmt in stmt.body:
            self._gen_statement(body_stmt)

        # Increment counter
        new_counter = self._new_temp()
        self._emit("+", arg1=counter, arg2=1, result=new_counter)
        self._emit("ASSIGN", arg1=new_counter, result=counter)

        # Jump back to start
        self._emit("GOTO", arg1=label_start)

        # End label
        self._emit("LABEL", arg1=label_end)

    # ─── Expression Generation ────────────────────────────────────────────

    def _gen_expression(self, expr) -> str:
        """
        Generate TAC for an expression. Returns the name of the temp/var
        holding the result.
        """
        if isinstance(expr, NumberLiteral):
            temp = self._new_temp()
            self._emit("ASSIGN", arg1=expr.value, result=temp)
            return temp

        elif isinstance(expr, Identifier):
            return expr.name

        elif isinstance(expr, BinaryOp):
            left = self._gen_expression(expr.left)
            right = self._gen_expression(expr.right)
            temp = self._new_temp()
            self._emit(expr.op, arg1=left, arg2=right, result=temp)
            return temp

        elif isinstance(expr, UnaryOp):
            operand = self._gen_expression(expr.operand)
            temp = self._new_temp()
            self._emit("UNARY_MINUS", arg1=operand, result=temp)
            return temp

        return "???"


def format_tac(instructions: List[TACInstruction]) -> str:
    """Return a formatted string of the TAC instructions."""
    lines = []
    for i, instr in enumerate(instructions):
        lines.append(f"{i:4d}: {instr}")
    return "\n".join(lines)

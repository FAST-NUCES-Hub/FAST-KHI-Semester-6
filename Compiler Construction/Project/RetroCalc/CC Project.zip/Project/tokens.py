"""
RetroCalc Compiler - Token Definitions
Defines all token types and the Token data structure used by the lexer.
"""

from enum import Enum, auto
from dataclasses import dataclass
from typing import Any


class TokenType(Enum):
    """Enumeration of all token types in the RetroCalc language."""

    # Literals
    INT_LITERAL = auto()
    FLOAT_LITERAL = auto()

    # Identifier
    IDENTIFIER = auto()

    # Arithmetic Operators
    PLUS = auto()       # +
    MINUS = auto()      # -
    STAR = auto()       # *
    SLASH = auto()      # /
    MOD = auto()        # %

    # Assignment
    ASSIGN = auto()     # =

    # Comparison Operators
    GT = auto()         # >
    LT = auto()         # <
    GTE = auto()        # >=
    LTE = auto()        # <=
    EQ = auto()         # ==
    NEQ = auto()        # !=

    # Delimiters
    LPAREN = auto()     # (
    RPAREN = auto()     # )

    # Keywords
    LET = auto()        # let
    PRINT = auto()      # print
    IF = auto()         # if
    END = auto()        # end
    LOOP = auto()       # loop

    # Special
    NEWLINE = auto()    # End of line
    EOF = auto()        # End of file


# Mapping of keyword strings to their token types
KEYWORDS = {
    "let": TokenType.LET,
    "print": TokenType.PRINT,
    "if": TokenType.IF,
    "end": TokenType.END,
    "loop": TokenType.LOOP,
}


@dataclass
class Token:
    """
    Represents a single token produced by the lexer.

    Attributes:
        type:   The TokenType of this token.
        value:  The raw value (string, int, or float).
        line:   The source line number (1-indexed).
        column: The source column number (1-indexed).
    """
    type: TokenType
    value: Any
    line: int
    column: int

    def __repr__(self):
        return f"Token({self.type.name}, {self.value!r}, line={self.line}, col={self.column})"

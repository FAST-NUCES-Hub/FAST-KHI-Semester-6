"""
RetroCalc Compiler - Interpreter
Executes Three-Address Code (TAC) instructions using a simple virtual machine.
"""

from typing import List, Dict
from tac_generator import TACInstruction
from errors import RetroCalcRuntimeError


class Interpreter:
    """
    A virtual-machine-style interpreter that executes TAC instructions.

    Maintains a variable store and supports arithmetic, comparisons,
    conditional/unconditional jumps, and print output.
    """

    def __init__(self):
        self.variables: Dict[str, any] = {}  # variable store
        self.output: List[str] = []           # captured print output

    def execute(self, instructions: List[TACInstruction], variables: Dict = None) -> List[str]:
        """
        Execute a list of TAC instructions.

        Args:
            instructions: The TAC instruction list to execute.
            variables: Optional initial variable state (for REPL continuity).

        Returns:
            list[str]: The lines of output produced by PRINT instructions.
        """
        if variables is not None:
            self.variables = dict(variables)
        else:
            self.variables = {}
        self.output = []

        # Build label → index mapping for jumps
        label_map = {}
        for i, instr in enumerate(instructions):
            if instr.op == "LABEL":
                label_map[instr.arg1] = i

        # Execute
        pc = 0  # program counter
        max_steps = 1_000_000  # safety limit
        steps = 0

        while pc < len(instructions):
            steps += 1
            if steps > max_steps:
                raise RetroCalcRuntimeError("Execution limit exceeded (possible infinite loop)")

            instr = instructions[pc]

            if instr.op == "ASSIGN":
                self.variables[instr.result] = self._resolve(instr.arg1)
                pc += 1

            elif instr.op in ("+", "-", "*", "/", "%"):
                val1 = self._resolve(instr.arg1)
                val2 = self._resolve(instr.arg2)
                self.variables[instr.result] = self._eval_arithmetic(instr.op, val1, val2)
                pc += 1

            elif instr.op in (">", "<", ">=", "<=", "==", "!="):
                val1 = self._resolve(instr.arg1)
                val2 = self._resolve(instr.arg2)
                self.variables[instr.result] = self._eval_comparison(instr.op, val1, val2)
                pc += 1

            elif instr.op == "UNARY_MINUS":
                val = self._resolve(instr.arg1)
                self.variables[instr.result] = -val
                pc += 1

            elif instr.op == "PRINT":
                val = self._resolve(instr.arg1)
                # Format output: display integers without decimal, floats with decimals
                if isinstance(val, float) and val == int(val):
                    formatted = str(int(val))
                else:
                    formatted = str(val)
                self.output.append(formatted)
                print(formatted)
                pc += 1

            elif instr.op == "LABEL":
                pc += 1  # labels are no-ops at runtime

            elif instr.op == "GOTO":
                if instr.arg1 in label_map:
                    pc = label_map[instr.arg1]
                else:
                    raise RetroCalcRuntimeError(f"Undefined label: {instr.arg1}")

            elif instr.op == "IF_FALSE":
                cond = self._resolve(instr.arg1)
                if not cond:
                    if instr.arg2 in label_map:
                        pc = label_map[instr.arg2]
                    else:
                        raise RetroCalcRuntimeError(f"Undefined label: {instr.arg2}")
                else:
                    pc += 1

            else:
                raise RetroCalcRuntimeError(f"Unknown instruction: {instr.op}")

        return self.output

    def _resolve(self, value):
        """
        Resolve a value: if it's a variable name (str), look it up;
        if it's a literal (int/float), return it directly.
        """
        if isinstance(value, (int, float)):
            return value
        if isinstance(value, str):
            if value in self.variables:
                return self.variables[value]
            raise RetroCalcRuntimeError(f"Undefined variable: '{value}'")
        return value

    @staticmethod
    def _eval_arithmetic(op, a, b):
        """Evaluate an arithmetic operation."""
        if op == '+': return a + b
        if op == '-': return a - b
        if op == '*': return a * b
        if op == '/':
            if b == 0:
                raise RetroCalcRuntimeError("Division by zero")
            if isinstance(a, int) and isinstance(b, int):
                return a // b
            return a / b
        if op == '%':
            if b == 0:
                raise RetroCalcRuntimeError("Modulo by zero")
            return a % b
        raise RetroCalcRuntimeError(f"Unknown arithmetic operator: {op}")

    @staticmethod
    def _eval_comparison(op, a, b):
        """Evaluate a comparison operation. Returns 1 (true) or 0 (false)."""
        if op == '>': return 1 if a > b else 0
        if op == '<': return 1 if a < b else 0
        if op == '>=': return 1 if a >= b else 0
        if op == '<=': return 1 if a <= b else 0
        if op == '==': return 1 if a == b else 0
        if op == '!=': return 1 if a != b else 0
        raise RetroCalcRuntimeError(f"Unknown comparison operator: {op}")

"""
RetroCalc Compiler - Parser (Syntax Analyzer)
Recursive-descent parser that transforms a token stream into an AST.

Grammar:
    program        → statement*
    statement      → let_stmt | print_stmt | if_stmt | loop_stmt
    let_stmt       → 'let' IDENT '=' expression NEWLINE
    print_stmt     → 'print' expression NEWLINE
    if_stmt        → 'if' expression NEWLINE statement* 'end' NEWLINE
    loop_stmt      → 'loop' expression NEWLINE statement* 'end' NEWLINE
    expression     → comparison
    comparison     → addition (( '>' | '<' | '>=' | '<=' | '==' | '!=' ) addition)?
    addition       → multiplication (( '+' | '-' ) multiplication)*
    multiplication → unary (( '*' | '/' | '%' ) unary)*
    unary          → ( '-' unary ) | primary
    primary        → INT_LITERAL | FLOAT_LITERAL | IDENT | '(' expression ')'
"""

from tokens import Token, TokenType
from ast_nodes import (
    Program, LetStatement, PrintStatement, IfStatement, LoopStatement,
    BinaryOp, UnaryOp, NumberLiteral, Identifier,
)
from errors import ParserError


class Parser:
    """
    Recursive-descent parser for the RetroCalc language.

    Consumes a list of tokens produced by the Lexer and builds
    an Abstract Syntax Tree (AST).
    """

    def __init__(self, tokens: list):
        self.tokens = tokens
        self.pos = 0

    # ─── Utility Methods ──────────────────────────────────────────────────

    def _current(self) -> Token:
        """Return the current token."""
        return self.tokens[self.pos]

    def _peek(self) -> Token:
        """Return the current token without consuming."""
        return self._current()

    def _advance(self) -> Token:
        """Consume and return the current token, then move forward."""
        token = self.tokens[self.pos]
        self.pos += 1
        return token

    def _expect(self, token_type: TokenType) -> Token:
        """
        Consume the current token if it matches the expected type.
        Raises ParserError otherwise.
        """
        token = self._current()
        if token.type != token_type:
            raise ParserError(
                f"Expected {token_type.name}, got {token.type.name} ({token.value!r})",
                token.line, token.column
            )
        return self._advance()

    def _match(self, *types) -> bool:
        """Check if the current token matches any of the given types."""
        return self._current().type in types

    def _skip_newlines(self):
        """Skip over any newline tokens."""
        while self._current().type == TokenType.NEWLINE:
            self._advance()

    def _expect_newline_or_eof(self):
        """Expect a newline or EOF (end of statement)."""
        if self._current().type not in (TokenType.NEWLINE, TokenType.EOF):
            raise ParserError(
                f"Expected end of statement, got {self._current().type.name} ({self._current().value!r})",
                self._current().line, self._current().column
            )
        if self._current().type == TokenType.NEWLINE:
            self._advance()

    # ─── Top-Level Parsing ────────────────────────────────────────────────

    def parse(self) -> Program:
        """
        Parse the token stream and return the root AST node.

        Returns:
            Program: The root of the AST.
        """
        self._skip_newlines()
        statements = []
        while not self._match(TokenType.EOF):
            stmt = self._parse_statement()
            statements.append(stmt)
            self._skip_newlines()
        return Program(statements=statements)

    # ─── Statement Parsing ────────────────────────────────────────────────

    def _parse_statement(self):
        """Parse a single statement based on the current token."""
        token = self._current()

        if token.type == TokenType.LET:
            return self._parse_let()
        elif token.type == TokenType.PRINT:
            return self._parse_print()
        elif token.type == TokenType.IF:
            return self._parse_if()
        elif token.type == TokenType.LOOP:
            return self._parse_loop()
        else:
            raise ParserError(
                f"Unexpected token: {token.type.name} ({token.value!r})",
                token.line, token.column
            )

    def _parse_let(self):
        """Parse: let <identifier> = <expression>"""
        token = self._advance()  # consume 'let'
        line = token.line

        name_token = self._expect(TokenType.IDENTIFIER)
        self._expect(TokenType.ASSIGN)
        expr = self._parse_expression()
        self._expect_newline_or_eof()

        return LetStatement(name=name_token.value, expression=expr, line=line)

    def _parse_print(self):
        """Parse: print <expression>"""
        token = self._advance()  # consume 'print'
        line = token.line

        expr = self._parse_expression()
        self._expect_newline_or_eof()

        return PrintStatement(expression=expr, line=line)

    def _parse_if(self):
        """Parse: if <expression> ... end"""
        token = self._advance()  # consume 'if'
        line = token.line

        condition = self._parse_expression()
        self._expect_newline_or_eof()
        self._skip_newlines()

        body = []
        while not self._match(TokenType.END, TokenType.EOF):
            body.append(self._parse_statement())
            self._skip_newlines()

        if self._match(TokenType.EOF):
            raise ParserError("Expected 'end' to close 'if' block", line)

        self._expect(TokenType.END)
        self._expect_newline_or_eof()

        return IfStatement(condition=condition, body=body, line=line)

    def _parse_loop(self):
        """Parse: loop <expression> ... end"""
        token = self._advance()  # consume 'loop'
        line = token.line

        count = self._parse_expression()
        self._expect_newline_or_eof()
        self._skip_newlines()

        body = []
        while not self._match(TokenType.END, TokenType.EOF):
            body.append(self._parse_statement())
            self._skip_newlines()

        if self._match(TokenType.EOF):
            raise ParserError("Expected 'end' to close 'loop' block", line)

        self._expect(TokenType.END)
        self._expect_newline_or_eof()

        return LoopStatement(count=count, body=body, line=line)

    # ─── Expression Parsing (Precedence Climbing) ─────────────────────────

    def _parse_expression(self):
        """Parse an expression (entry point)."""
        return self._parse_comparison()

    def _parse_comparison(self):
        """Parse comparison: addition (( '>' | '<' | '>=' | '<=' | '==' | '!=' ) addition)?"""
        left = self._parse_addition()
        comparison_ops = (TokenType.GT, TokenType.LT, TokenType.GTE,
                          TokenType.LTE, TokenType.EQ, TokenType.NEQ)

        if self._match(*comparison_ops):
            op_token = self._advance()
            right = self._parse_addition()
            left = BinaryOp(op=op_token.value, left=left, right=right, line=op_token.line)

        return left

    def _parse_addition(self):
        """Parse addition/subtraction: multiplication (( '+' | '-' ) multiplication)*"""
        left = self._parse_multiplication()

        while self._match(TokenType.PLUS, TokenType.MINUS):
            op_token = self._advance()
            right = self._parse_multiplication()
            left = BinaryOp(op=op_token.value, left=left, right=right, line=op_token.line)

        return left

    def _parse_multiplication(self):
        """Parse multiplication/division/modulo: unary (( '*' | '/' | '%' ) unary)*"""
        left = self._parse_unary()

        while self._match(TokenType.STAR, TokenType.SLASH, TokenType.MOD):
            op_token = self._advance()
            right = self._parse_unary()
            left = BinaryOp(op=op_token.value, left=left, right=right, line=op_token.line)

        return left

    def _parse_unary(self):
        """Parse unary: ( '-' unary ) | primary"""
        if self._match(TokenType.MINUS):
            op_token = self._advance()
            operand = self._parse_unary()
            return UnaryOp(op='-', operand=operand, line=op_token.line)
        return self._parse_primary()

    def _parse_primary(self):
        """Parse primary: NUMBER | IDENTIFIER | '(' expression ')'"""
        token = self._current()

        if token.type == TokenType.INT_LITERAL:
            self._advance()
            return NumberLiteral(value=token.value, line=token.line)

        if token.type == TokenType.FLOAT_LITERAL:
            self._advance()
            return NumberLiteral(value=token.value, line=token.line)

        if token.type == TokenType.IDENTIFIER:
            self._advance()
            return Identifier(name=token.value, line=token.line)

        if token.type == TokenType.LPAREN:
            self._advance()  # consume '('
            expr = self._parse_expression()
            self._expect(TokenType.RPAREN)
            return expr

        raise ParserError(
            f"Expected expression, got {token.type.name} ({token.value!r})",
            token.line, token.column
        )

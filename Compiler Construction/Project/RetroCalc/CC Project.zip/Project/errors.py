"""
RetroCalc Compiler - Error Definitions
Custom exception classes for all compiler phases with source location info.

Error format follows: "Error at line <N>: <message>"
"""


class RetroCalcError(Exception):
    """Base exception for all RetroCalc compiler errors."""

    def __init__(self, message, line=None, column=None):
        self.line = line
        self.column = column
        if line is not None:
            message = f"Error at line {line}: {message}"
        super().__init__(message)


class LexerError(RetroCalcError):
    """Raised when the lexer encounters an invalid character or malformed token."""

    def __init__(self, message, line=None, column=None):
        super().__init__(f"Lexer Error: {message}", line, column)


class ParserError(RetroCalcError):
    """Raised when the parser encounters an unexpected token or invalid syntax."""

    def __init__(self, message, line=None, column=None):
        super().__init__(f"Syntax Error: {message}", line, column)


class SemanticError(RetroCalcError):
    """Raised for semantic issues like undeclared variables or type mismatches."""

    def __init__(self, message, line=None, column=None):
        super().__init__(f"Semantic Error: {message}", line, column)


class RetroCalcRuntimeError(RetroCalcError):
    """Raised for runtime errors like division by zero."""

    def __init__(self, message, line=None, column=None):
        super().__init__(f"Runtime Error: {message}", line, column)

"""
RetroCalc Compiler - Semantic Analyzer
Walks the AST to validate variable declarations, usage, and type consistency.
"""

from ast_nodes import (
    Program, LetStatement, PrintStatement, IfStatement, LoopStatement,
    BinaryOp, UnaryOp, NumberLiteral, Identifier,
)
from errors import SemanticError


class SemanticAnalyzer:
    """
    Performs semantic analysis on the RetroCalc AST.

    Checks:
      - Variables are declared before use
      - Tracks variable types (int vs float)
      - Warns about unused variables
    """

    def __init__(self):
        self.declared_vars = {}   # name -> {'type': 'int'|'float', 'line': int}
        self.used_vars = set()    # set of variable names that have been read
        self.warnings = []        # list of warning messages
        self.errors = []          # list of error messages

    def analyze(self, ast: Program):
        """
        Run semantic analysis on the program AST.

        Args:
            ast: The root Program node.

        Raises:
            SemanticError: If any semantic error is found.
        """
        self.declared_vars = {}
        self.used_vars = set()
        self.warnings = []
        self.errors = []

        for stmt in ast.statements:
            self._analyze_statement(stmt)

        # Check for unused variables
        for var_name, info in self.declared_vars.items():
            if var_name not in self.used_vars:
                self.warnings.append(
                    f"Warning: Variable '{var_name}' is declared (line {info['line']}) but never used"
                )

        if self.errors:
            # Raise the first error with proper formatting
            raise SemanticError(self.errors[0]['message'], line=self.errors[0]['line'])

    def _analyze_statement(self, stmt):
        """Analyze a single statement node."""
        if isinstance(stmt, LetStatement):
            self._analyze_let(stmt)
        elif isinstance(stmt, PrintStatement):
            self._analyze_print(stmt)
        elif isinstance(stmt, IfStatement):
            self._analyze_if(stmt)
        elif isinstance(stmt, LoopStatement):
            self._analyze_loop(stmt)
        else:
            self.errors.append({'message': f"Unknown statement type: {type(stmt).__name__}", 'line': 0})

    def _analyze_let(self, stmt: LetStatement):
        """Analyze a let statement: check the expression, register the variable."""
        expr_type = self._analyze_expression(stmt.expression)
        self.declared_vars[stmt.name] = {
            'type': expr_type,
            'line': stmt.line,
        }

    def _analyze_print(self, stmt: PrintStatement):
        """Analyze a print statement: check the expression."""
        self._analyze_expression(stmt.expression)

    def _analyze_if(self, stmt: IfStatement):
        """Analyze an if statement: check condition and body."""
        self._analyze_expression(stmt.condition)
        for body_stmt in stmt.body:
            self._analyze_statement(body_stmt)

    def _analyze_loop(self, stmt: LoopStatement):
        """Analyze a loop statement: check count expression and body."""
        self._analyze_expression(stmt.count)
        for body_stmt in stmt.body:
            self._analyze_statement(body_stmt)

    def _analyze_expression(self, expr) -> str:
        """
        Analyze an expression node and return its inferred type ('int' or 'float').

        Args:
            expr: An expression AST node.

        Returns:
            str: The inferred type of the expression.
        """
        if isinstance(expr, NumberLiteral):
            if isinstance(expr.value, float):
                return 'float'
            return 'int'

        elif isinstance(expr, Identifier):
            if expr.name not in self.declared_vars:
                self.errors.append({
                    'message': f"Undefined variable '{expr.name}'",
                    'line': expr.line
                })
                return 'int'  # default to avoid cascading errors
            self.used_vars.add(expr.name)
            return self.declared_vars[expr.name]['type']

        elif isinstance(expr, BinaryOp):
            left_type = self._analyze_expression(expr.left)
            right_type = self._analyze_expression(expr.right)
            # If either operand is float, result is float
            if left_type == 'float' or right_type == 'float':
                return 'float'
            # Division always produces float (unless both are int and divide evenly,
            # but for simplicity we keep int semantics for / when both are int)
            return 'int'

        elif isinstance(expr, UnaryOp):
            return self._analyze_expression(expr.operand)

        else:
            self.errors.append({'message': f"Unknown expression type: {type(expr).__name__}", 'line': 0})
            return 'int'

    def get_report(self) -> str:
        """Return a formatted report of the semantic analysis."""
        lines = []
        lines.append("=== Semantic Analysis Report ===")

        if self.declared_vars:
            lines.append("\nDeclared Variables:")
            for name, info in self.declared_vars.items():
                used = "[x] used" if name in self.used_vars else "[ ] unused"
                lines.append(f"  {name}: {info['type']} (line {info['line']}) [{used}]")

        if self.warnings:
            lines.append("\nWarnings:")
            for w in self.warnings:
                lines.append(f"  {w}")

        if not self.errors and not self.warnings:
            lines.append("  No issues found.")

        return "\n".join(lines)

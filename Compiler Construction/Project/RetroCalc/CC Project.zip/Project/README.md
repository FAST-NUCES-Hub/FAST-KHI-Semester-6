# RetroCalc Compiler

A Python-based compiler for **RetroCalc**, a retro-style calculator programming language designed for arithmetic computations, variable storage, and basic program logic — similar to early programmable calculators from the 1980s.

The compiler demonstrates all phases of compiler construction:

1. **Lexical Analysis** — Tokenizes source code
2. **Parsing** — Builds an Abstract Syntax Tree (AST)
3. **Semantic Analysis** — Validates variables, types, and usage
4. **Intermediate Code Generation** — Produces Three-Address Code (TAC)
5. **Optimization** — Constant folding, propagation, and dead code elimination
6. **Execution** — Interprets the optimized TAC via a virtual machine

---

## Language Features

| Feature             | Description                                    |
|---------------------|------------------------------------------------|
| Variables           | Integer and floating-point (`let x = 42`)      |
| Arithmetic          | `+`, `-`, `*`, `/`, `%`                        |
| Comparisons         | `>`, `<`, `>=`, `<=`, `==`, `!=`               |
| Print               | Display values (`print x`)                     |
| If Statements       | Conditional blocks (`if ... end`)              |
| Loops               | Count-based loops (`loop N ... end`)           |
| Parentheses         | Expression grouping (`(a + b) * c`)            |
| Comments            | Lines starting with `#`                        |
| REPL                | Interactive mode for testing expressions       |

---

## Getting Started

### Requirements

- Python 3.7+

### Running a Program

```bash
python main.py examples/basic.rc
```

### Debug Mode (Shows All Compiler Phases)

```bash
python main.py examples/basic.rc --debug
```

### Interactive REPL

```bash
python main.py
```

REPL commands:
- `exit` — Quit the REPL
- `vars` — Show all defined variables
- `clear` — Clear all variables
- `debug` — Toggle debug mode on/off

---

## Example Programs

### Basic Arithmetic

```
let x = 10
let y = 20
let sum = x + y
let product = x * y
print sum
print product

if sum > 20
    print sum + 5
end
```

**Output:**
```
30
200
35
```

### Loop

```
let i = 0
loop 5
    print i
    let i = i + 1
end
```

**Output:**
```
0
1
2
3
4
```

---

## Compiler Architecture

```
Source Code (.rc file)
        │
        ▼
  ┌──────────┐
  │  Lexer   │  → Token Stream
  └──────────┘
        │
        ▼
  ┌──────────┐
  │  Parser  │  → Abstract Syntax Tree (AST)
  └──────────┘
        │
        ▼
  ┌──────────────────┐
  │ Semantic Analyzer│  → Validated AST + Warnings
  └──────────────────┘
        │
        ▼
  ┌───────────────┐
  │ TAC Generator │  → Three-Address Code (IR)
  └───────────────┘
        │
        ▼
  ┌──────────┐
  │ Optimizer│  → Optimized TAC
  └──────────┘
        │
        ▼
  ┌─────────────┐
  │ Interpreter │  → Program Output
  └─────────────┘
```

---

## Project Structure

| File                     | Description                                     |
|--------------------------|-------------------------------------------------|
| `main.py`                | CLI entry point, REPL, debug mode               |
| `lexer.py`               | Lexical analyzer (tokenizer)                    |
| `parser.py`              | Recursive-descent parser                        |
| `ast_nodes.py`           | AST node class definitions + pretty printer     |
| `semantic_analyzer.py`   | Semantic validation pass                        |
| `tac_generator.py`       | Three-Address Code generation                   |
| `optimizer.py`           | Constant folding & dead code elimination        |
| `interpreter.py`         | TAC execution engine                            |
| `tokens.py`              | Token type definitions                          |
| `errors.py`              | Custom exception classes                        |
| `examples/`              | Sample RetroCalc programs                       |

---

## Optimizations

The optimizer performs three passes:

1. **Constant Folding** — Evaluates operations with constant operands at compile time
   - `t0 = 3 + 5` → `t0 = 8`

2. **Constant Propagation** — Substitutes known constant values into subsequent uses

3. **Dead Code Elimination** — Removes assignments to temporaries that are never read

"""
RetroCalc Compiler - Optimizer
Performs optimization passes on the Three-Address Code (TAC):
  1. Constant Folding   — evaluate constant expressions at compile time
  2. Constant Propagation — replace variable uses with known constant values
  3. Dead Code Elimination — remove assignments whose results are never read
"""

from typing import List, Dict, Set
from tac_generator import TACInstruction

# Operators that produce a computed result
ARITHMETIC_OPS = {"+", "-", "*", "/", "%"}
COMPARISON_OPS = {">", "<", ">=", "<=", "==", "!="}
ALL_BINARY_OPS = ARITHMETIC_OPS | COMPARISON_OPS


class Optimizer:
    """
    Performs optimization passes on a list of TACInstruction objects.
    """

    def __init__(self):
        self.optimizations_log = []  # human-readable log of changes

    def optimize(self, instructions: List[TACInstruction]) -> List[TACInstruction]:
        """
        Run all optimization passes and return the optimized instruction list.

        Args:
            instructions: The original TAC instructions.

        Returns:
            list[TACInstruction]: The optimized TAC instructions.
        """
        self.optimizations_log = []
        result = list(instructions)  # work on a copy

        result = self._constant_folding(result)
        result = self._constant_propagation(result)
        result = self._dead_code_elimination(result)

        return result

    # ─── Pass 1: Constant Folding ─────────────────────────────────────────

    def _constant_folding(self, instructions: List[TACInstruction]) -> List[TACInstruction]:
        """
        Evaluate binary operations where both operands are constants.
        e.g., t0 = 3 + 5 → t0 = 8
        """
        result = []
        for instr in instructions:
            if instr.op in ALL_BINARY_OPS:
                val1 = self._try_number(instr.arg1)
                val2 = self._try_number(instr.arg2)

                if val1 is not None and val2 is not None:
                    folded = self._eval_op(instr.op, val1, val2)
                    if folded is not None:
                        self.optimizations_log.append(
                            f"Constant Folding: {instr.result} = {val1} {instr.op} {val2} -> {instr.result} = {folded}"
                        )
                        result.append(TACInstruction(
                            op="ASSIGN", arg1=folded, result=instr.result
                        ))
                        continue

            if instr.op == "UNARY_MINUS":
                val = self._try_number(instr.arg1)
                if val is not None:
                    folded = -val
                    self.optimizations_log.append(
                        f"Constant Folding: {instr.result} = -{val} -> {instr.result} = {folded}"
                    )
                    result.append(TACInstruction(
                        op="ASSIGN", arg1=folded, result=instr.result
                    ))
                    continue

            result.append(instr)

        return result

    # ─── Pass 2: Constant Propagation ─────────────────────────────────────

    def _constant_propagation(self, instructions: List[TACInstruction]) -> List[TACInstruction]:
        """
        Track which temporaries/variables hold constant values and substitute
        those constants into subsequent uses.
        """
        constants: Dict[str, any] = {}  # var_name -> constant value
        result = []

        for instr in instructions:
            # Labels and GOTOs reset our knowledge (control flow merge)
            if instr.op in ("LABEL", "GOTO", "IF_FALSE"):
                # Clear constant knowledge at control flow boundaries
                if instr.op == "LABEL":
                    constants.clear()

                # Substitute any known constants in IF_FALSE condition
                if instr.op == "IF_FALSE" and isinstance(instr.arg1, str) and instr.arg1 in constants:
                    old = instr.arg1
                    instr = TACInstruction(
                        op=instr.op, arg1=constants[old], arg2=instr.arg2, result=instr.result
                    )
                    self.optimizations_log.append(
                        f"Constant Propagation: replaced {old} with {constants[old]} in IF_FALSE"
                    )
                result.append(instr)
                continue

            # Substitute constants into arg1 and arg2
            new_arg1 = instr.arg1
            new_arg2 = instr.arg2

            if isinstance(instr.arg1, str) and instr.arg1 in constants:
                new_arg1 = constants[instr.arg1]
                self.optimizations_log.append(
                    f"Constant Propagation: replaced {instr.arg1} with {new_arg1}"
                )

            if isinstance(instr.arg2, str) and instr.arg2 in constants:
                new_arg2 = constants[instr.arg2]
                self.optimizations_log.append(
                    f"Constant Propagation: replaced {instr.arg2} with {new_arg2}"
                )

            new_instr = TACInstruction(
                op=instr.op, arg1=new_arg1, arg2=new_arg2, result=instr.result
            )

            # Track constants: if this is ASSIGN with a literal value
            if new_instr.op == "ASSIGN" and self._try_number(new_instr.arg1) is not None:
                constants[new_instr.result] = new_instr.arg1
            elif new_instr.result and isinstance(new_instr.result, str):
                # Result is computed — no longer a known constant
                constants.pop(new_instr.result, None)

            result.append(new_instr)

        # Second pass: fold any newly constant expressions
        result = self._constant_folding(result)

        return result

    # ─── Pass 3: Dead Code Elimination ────────────────────────────────────

    def _dead_code_elimination(self, instructions: List[TACInstruction]) -> List[TACInstruction]:
        """
        Remove assignments to temporaries that are never read.
        Only removes temporary variables (t0, t1, ...) — user variables are kept.
        """
        # Collect all variable names that are READ somewhere
        used: Set[str] = set()
        for instr in instructions:
            if instr.op == "PRINT":
                if isinstance(instr.arg1, str):
                    used.add(instr.arg1)
            elif instr.op == "IF_FALSE":
                if isinstance(instr.arg1, str):
                    used.add(instr.arg1)
            elif instr.op in ("LABEL", "GOTO"):
                pass  # no variable reads
            else:
                # arg1 and arg2 are reads (if they are variable names)
                if isinstance(instr.arg1, str):
                    used.add(instr.arg1)
                if isinstance(instr.arg2, str):
                    used.add(instr.arg2)

        # Remove assignments to unused temporaries
        result = []
        for instr in instructions:
            if (instr.op == "ASSIGN" or instr.op in ALL_BINARY_OPS or instr.op == "UNARY_MINUS"):
                target = instr.result
                # Only eliminate temporaries (t0, t1, ...), not user variables
                if target and isinstance(target, str) and target.startswith("t") and target[1:].isdigit():
                    if target not in used:
                        self.optimizations_log.append(
                            f"Dead Code Elimination: removed assignment to unused temp '{target}'"
                        )
                        continue
            result.append(instr)

        return result

    # ─── Helpers ──────────────────────────────────────────────────────────

    @staticmethod
    def _try_number(value):
        """If value is a numeric literal, return it; otherwise return None."""
        if isinstance(value, (int, float)):
            return value
        return None

    @staticmethod
    def _eval_op(op, a, b):
        """Evaluate a binary operation on two constants. Returns None on error."""
        try:
            if op == '+': return a + b
            if op == '-': return a - b
            if op == '*': return a * b
            if op == '/':
                if b == 0:
                    return None
                return a / b if isinstance(a, float) or isinstance(b, float) else a // b
            if op == '%':
                if b == 0:
                    return None
                return a % b
            if op == '>': return 1 if a > b else 0
            if op == '<': return 1 if a < b else 0
            if op == '>=': return 1 if a >= b else 0
            if op == '<=': return 1 if a <= b else 0
            if op == '==': return 1 if a == b else 0
            if op == '!=': return 1 if a != b else 0
        except Exception:
            return None
        return None

    def get_report(self) -> str:
        """Return a formatted log of all optimizations performed."""
        if not self.optimizations_log:
            return "No optimizations performed."
        lines = ["Optimizations Applied:"]
        for entry in self.optimizations_log:
            lines.append(f"  - {entry}")
        return "\n".join(lines)

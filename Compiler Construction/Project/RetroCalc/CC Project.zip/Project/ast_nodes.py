"""
RetroCalc Compiler - AST Node Definitions
Defines the Abstract Syntax Tree node classes produced by the parser.
"""

from dataclasses import dataclass, field
from typing import List, Union


# ─── Expression Nodes ────────────────────────────────────────────────────────

@dataclass
class NumberLiteral:
    """A numeric literal (integer or float)."""
    value: Union[int, float]
    line: int = 0

    def __repr__(self):
        return f"NumberLiteral({self.value})"


@dataclass
class Identifier:
    """A variable reference."""
    name: str
    line: int = 0

    def __repr__(self):
        return f"Identifier({self.name})"


@dataclass
class BinaryOp:
    """A binary operation: left op right."""
    op: str
    left: object  # Expression node
    right: object  # Expression node
    line: int = 0

    def __repr__(self):
        return f"BinaryOp({self.left} {self.op} {self.right})"


@dataclass
class UnaryOp:
    """A unary operation (e.g., negation)."""
    op: str
    operand: object  # Expression node
    line: int = 0

    def __repr__(self):
        return f"UnaryOp({self.op}{self.operand})"


# ─── Statement Nodes ─────────────────────────────────────────────────────────

@dataclass
class LetStatement:
    """Variable assignment: let <name> = <expression>."""
    name: str
    expression: object  # Expression node
    line: int = 0

    def __repr__(self):
        return f"LetStatement({self.name} = {self.expression})"


@dataclass
class PrintStatement:
    """Print statement: print <expression>."""
    expression: object  # Expression node
    line: int = 0

    def __repr__(self):
        return f"PrintStatement({self.expression})"


@dataclass
class IfStatement:
    """If statement: if <condition> ... end."""
    condition: object  # Expression node
    body: List = field(default_factory=list)
    line: int = 0

    def __repr__(self):
        return f"IfStatement(cond={self.condition}, body=[{len(self.body)} stmts])"


@dataclass
class LoopStatement:
    """Loop statement: loop <count> ... end."""
    count: object  # Expression node (number of iterations)
    body: List = field(default_factory=list)
    line: int = 0

    def __repr__(self):
        return f"LoopStatement(count={self.count}, body=[{len(self.body)} stmts])"


@dataclass
class Program:
    """The root AST node containing all top-level statements."""
    statements: List = field(default_factory=list)

    def __repr__(self):
        return f"Program([{len(self.statements)} statements])"


# ─── AST Pretty Printer ──────────────────────────────────────────────────────

def pretty_print_ast(node, indent=0):
    """Return a human-readable, indented string representation of the AST."""
    prefix = "  " * indent
    lines = []

    if isinstance(node, Program):
        lines.append(f"{prefix}Program")
        for stmt in node.statements:
            lines.append(pretty_print_ast(stmt, indent + 1))

    elif isinstance(node, LetStatement):
        lines.append(f"{prefix}LetStatement: {node.name} =")
        lines.append(pretty_print_ast(node.expression, indent + 1))

    elif isinstance(node, PrintStatement):
        lines.append(f"{prefix}PrintStatement:")
        lines.append(pretty_print_ast(node.expression, indent + 1))

    elif isinstance(node, IfStatement):
        lines.append(f"{prefix}IfStatement:")
        lines.append(f"{prefix}  Condition:")
        lines.append(pretty_print_ast(node.condition, indent + 2))
        lines.append(f"{prefix}  Body:")
        for stmt in node.body:
            lines.append(pretty_print_ast(stmt, indent + 2))

    elif isinstance(node, LoopStatement):
        lines.append(f"{prefix}LoopStatement:")
        lines.append(f"{prefix}  Count:")
        lines.append(pretty_print_ast(node.count, indent + 2))
        lines.append(f"{prefix}  Body:")
        for stmt in node.body:
            lines.append(pretty_print_ast(stmt, indent + 2))

    elif isinstance(node, BinaryOp):
        lines.append(f"{prefix}BinaryOp: {node.op}")
        lines.append(pretty_print_ast(node.left, indent + 1))
        lines.append(pretty_print_ast(node.right, indent + 1))

    elif isinstance(node, UnaryOp):
        lines.append(f"{prefix}UnaryOp: {node.op}")
        lines.append(pretty_print_ast(node.operand, indent + 1))

    elif isinstance(node, NumberLiteral):
        lines.append(f"{prefix}NumberLiteral: {node.value}")

    elif isinstance(node, Identifier):
        lines.append(f"{prefix}Identifier: {node.name}")

    else:
        lines.append(f"{prefix}Unknown node: {node}")

    return "\n".join(lines)

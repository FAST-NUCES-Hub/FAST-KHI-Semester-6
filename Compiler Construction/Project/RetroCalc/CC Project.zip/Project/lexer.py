"""
RetroCalc Compiler - Lexer (Lexical Analyzer)
Transforms source code text into a stream of tokens.
"""

from tokens import Token, TokenType, KEYWORDS
from errors import LexerError


class Lexer:
    """
    Lexical analyzer for the RetroCalc language.

    Scans the source string character-by-character and produces
    a list of Token objects. Newlines are treated as significant
    statement separators.
    """

    def __init__(self, source: str):
        self.source = source
        self.pos = 0
        self.line = 1
        self.column = 1
        self.tokens = []

    def _current_char(self):
        """Return the current character or None if at end."""
        if self.pos < len(self.source):
            return self.source[self.pos]
        return None

    def _peek(self):
        """Return the next character without consuming it."""
        next_pos = self.pos + 1
        if next_pos < len(self.source):
            return self.source[next_pos]
        return None

    def _advance(self):
        """Consume the current character and advance position."""
        char = self.source[self.pos]
        self.pos += 1
        if char == '\n':
            self.line += 1
            self.column = 1
        else:
            self.column += 1
        return char

    def _skip_whitespace(self):
        """Skip spaces and tabs (not newlines)."""
        while self._current_char() is not None and self._current_char() in ' \t\r':
            self._advance()

    def _skip_comment(self):
        """Skip a comment line (from # to end of line)."""
        while self._current_char() is not None and self._current_char() != '\n':
            self._advance()

    def _read_number(self):
        """Read an integer or floating-point number."""
        start_col = self.column
        num_str = ""
        has_dot = False

        while self._current_char() is not None and (self._current_char().isdigit() or self._current_char() == '.'):
            if self._current_char() == '.':
                if has_dot:
                    raise LexerError("Invalid number: multiple decimal points", self.line, start_col)
                has_dot = True
            num_str += self._advance()

        if has_dot:
            return Token(TokenType.FLOAT_LITERAL, float(num_str), self.line, start_col)
        else:
            return Token(TokenType.INT_LITERAL, int(num_str), self.line, start_col)

    def _read_identifier_or_keyword(self):
        """Read an identifier or keyword."""
        start_col = self.column
        name = ""

        while self._current_char() is not None and (self._current_char().isalnum() or self._current_char() == '_'):
            name += self._advance()

        # Check if it's a keyword
        if name in KEYWORDS:
            return Token(KEYWORDS[name], name, self.line, start_col)
        else:
            return Token(TokenType.IDENTIFIER, name, self.line, start_col)

    def tokenize(self):
        """
        Scan the entire source and return a list of tokens.

        Returns:
            list[Token]: The complete token stream ending with EOF.

        Raises:
            LexerError: If an unexpected character is encountered.
        """
        self.tokens = []

        while self._current_char() is not None:
            self._skip_whitespace()
            char = self._current_char()

            if char is None:
                break

            # --- Comments ---
            if char == '#':
                self._skip_comment()
                continue

            # --- Newlines (statement separators) ---
            if char == '\n':
                # Avoid duplicate newlines
                if self.tokens and self.tokens[-1].type != TokenType.NEWLINE:
                    self.tokens.append(Token(TokenType.NEWLINE, '\\n', self.line, self.column))
                self._advance()
                continue

            # --- Numbers ---
            if char.isdigit():
                self.tokens.append(self._read_number())
                continue

            # --- Identifiers / Keywords ---
            if char.isalpha() or char == '_':
                self.tokens.append(self._read_identifier_or_keyword())
                continue

            # --- Two-character operators ---
            col = self.column
            if char == '>' and self._peek() == '=':
                self._advance()
                self._advance()
                self.tokens.append(Token(TokenType.GTE, '>=', self.line, col))
                continue
            if char == '<' and self._peek() == '=':
                self._advance()
                self._advance()
                self.tokens.append(Token(TokenType.LTE, '<=', self.line, col))
                continue
            if char == '=' and self._peek() == '=':
                self._advance()
                self._advance()
                self.tokens.append(Token(TokenType.EQ, '==', self.line, col))
                continue
            if char == '!' and self._peek() == '=':
                self._advance()
                self._advance()
                self.tokens.append(Token(TokenType.NEQ, '!=', self.line, col))
                continue

            # --- Single-character operators ---
            single_char_tokens = {
                '+': TokenType.PLUS,
                '-': TokenType.MINUS,
                '*': TokenType.STAR,
                '/': TokenType.SLASH,
                '%': TokenType.MOD,
                '=': TokenType.ASSIGN,
                '>': TokenType.GT,
                '<': TokenType.LT,
                '(': TokenType.LPAREN,
                ')': TokenType.RPAREN,
            }

            if char in single_char_tokens:
                self._advance()
                self.tokens.append(Token(single_char_tokens[char], char, self.line, col))
                continue

            # --- Unknown character ---
            raise LexerError(f"Unexpected character: '{char}'", self.line, self.column)

        # Add EOF token
        self.tokens.append(Token(TokenType.EOF, None, self.line, self.column))
        return self.tokens

"""
RetroCalc Compiler - Main Entry Point
Provides the CLI interface, debug mode, and interactive REPL.

Usage:
    python main.py <file.rc>              Run a RetroCalc program
    python main.py <file.rc> --debug      Run with debug output (all phases)
    python main.py                        Enter interactive REPL mode
    python main.py --interactive          Enter interactive REPL mode
"""

import sys
import os

from lexer import Lexer
from parser import Parser
from ast_nodes import pretty_print_ast
from semantic_analyzer import SemanticAnalyzer
from tac_generator import TACGenerator, format_tac
from optimizer import Optimizer
from interpreter import Interpreter
from errors import RetroCalcError


# ===============================================================================
# Compilation Pipeline
# ===============================================================================

def compile_and_run(source: str, debug: bool = False, repl_state: dict = None):
    """
    Run the full compiler pipeline on a source string.

    Args:
        source: The RetroCalc source code.
        debug: If True, print detailed output for each phase.
        repl_state: Optional dict with 'variables' for REPL continuity.

    Returns:
        dict: Updated REPL state (variables, etc.) or None.
    """

    # -- Phase 1: Lexical Analysis -----------------------------------------
    if debug:
        print("=" * 60)
        print("  PHASE 1: LEXICAL ANALYSIS")
        print("=" * 60)

    lexer = Lexer(source)
    tokens = lexer.tokenize()

    if debug:
        print("\nTokens:")
        for tok in tokens:
            print(f"  {tok}")
        print()

    # -- Phase 2: Parsing --------------------------------------------------
    if debug:
        print("=" * 60)
        print("  PHASE 2: PARSING (AST Construction)")
        print("=" * 60)

    parser = Parser(tokens)
    ast = parser.parse()

    if debug:
        print("\nAbstract Syntax Tree:")
        print(pretty_print_ast(ast))
        print()

    # -- Phase 3: Semantic Analysis ----------------------------------------
    if debug:
        print("=" * 60)
        print("  PHASE 3: SEMANTIC ANALYSIS")
        print("=" * 60)

    analyzer = SemanticAnalyzer()

    # In REPL mode, pre-declare existing variables
    if repl_state and 'variables' in repl_state:
        for var_name, var_value in repl_state['variables'].items():
            var_type = 'float' if isinstance(var_value, float) else 'int'
            analyzer.declared_vars[var_name] = {'type': var_type, 'line': 0}

    analyzer.analyze(ast)

    if debug:
        print(f"\n{analyzer.get_report()}")
        if analyzer.warnings:
            for w in analyzer.warnings:
                print(f"  {w}")
        print()

    # -- Phase 4: Three-Address Code Generation ----------------------------
    if debug:
        print("=" * 60)
        print("  PHASE 4: INTERMEDIATE CODE (Three-Address Code)")
        print("=" * 60)

    tac_gen = TACGenerator()
    tac = tac_gen.generate(ast)

    if debug:
        print("\nUnoptimized TAC:")
        print(format_tac(tac))
        print()

    # -- Phase 5: Optimization ---------------------------------------------
    if debug:
        print("=" * 60)
        print("  PHASE 5: OPTIMIZATION")
        print("=" * 60)

    optimizer = Optimizer()
    optimized_tac = optimizer.optimize(tac)

    if debug:
        print(f"\n{optimizer.get_report()}")
        print("\nOptimized TAC:")
        print(format_tac(optimized_tac))
        print()

    # -- Phase 6: Execution ------------------------------------------------
    if debug:
        print("=" * 60)
        print("  PHASE 6: EXECUTION")
        print("=" * 60)
        print()

    interpreter = Interpreter()
    variables = repl_state['variables'] if repl_state else None
    interpreter.execute(optimized_tac, variables=variables)

    # Return updated state for REPL
    return {'variables': interpreter.variables}


# ===============================================================================
# REPL Mode
# ===============================================================================

def run_repl():
    """Run the interactive REPL (Read-Eval-Print Loop)."""
    print("+----------------------------------------------+")
    print("|        RetroCalc Interactive REPL            |")
    print("|  Type expressions or statements to execute.  |")
    print("|  Commands: exit, vars, clear, debug          |")
    print("+----------------------------------------------+")
    print()

    repl_state = {'variables': {}}
    debug_mode = False

    while True:
        try:
            line = input("RetroCalc> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break

        if not line:
            continue

        # -- Special Commands --
        if line.lower() == 'exit':
            print("Goodbye!")
            break

        if line.lower() == 'vars':
            if repl_state['variables']:
                print("Current variables:")
                for name, value in repl_state['variables'].items():
                    # Skip internal temporaries
                    if name.startswith('t') and name[1:].isdigit():
                        continue
                    print(f"  {name} = {value}")
            else:
                print("No variables defined.")
            continue

        if line.lower() == 'clear':
            repl_state = {'variables': {}}
            print("Variables cleared.")
            continue

        if line.lower() == 'debug':
            debug_mode = not debug_mode
            print(f"Debug mode: {'ON' if debug_mode else 'OFF'}")
            continue

        # -- Compile and Execute --
        try:
            result = compile_and_run(line, debug=debug_mode, repl_state=repl_state)
            if result:
                repl_state = result
        except RetroCalcError as e:
            print(f"{e}")
        except Exception as e:
            print(f"Internal error: {e}")


# ===============================================================================
# File Execution Mode
# ===============================================================================

def run_file(filepath: str, debug: bool = False):
    """
    Read and execute a RetroCalc source file.

    Args:
        filepath: Path to the .rc file.
        debug: If True, show all compiler phase details.
    """
    if not os.path.exists(filepath):
        print(f"Error: File not found: {filepath}")
        sys.exit(1)

    with open(filepath, 'r') as f:
        source = f.read()

    if debug:
        print("+----------------------------------------------+")
        print("|     RetroCalc Compiler -- Debug Mode          |")
        print("+----------------------------------------------+")
        print(f"  Source file: {filepath}")
        print(f"  Source length: {len(source)} characters")
        print()
        print("Source Code:")
        print("-" * 40)
        for i, line in enumerate(source.splitlines(), 1):
            print(f"  {i:3d} | {line}")
        print("-" * 40)
        print()

    try:
        compile_and_run(source, debug=debug)
    except RetroCalcError as e:
        print(f"{e}")
        sys.exit(1)


# ===============================================================================
# Entry Point
# ===============================================================================

def main():
    """Main entry point -- parse CLI args and dispatch."""
    args = sys.argv[1:]

    if not args or "--interactive" in args:
        # No arguments or --interactive flag -> REPL mode
        run_repl()
    else:
        filepath = args[0]
        debug = "--debug" in args
        run_file(filepath, debug=debug)


if __name__ == "__main__":
    main()


#include "MinimaxEngine.h"
#include <algorithm>
#include <sstream>
#include <cmath>

// Piece-square tables (from white's perspective, index [row][col] where row 0 = rank 1)
static const int pawnTable[8][8] = {
	{ 0,  0,  0,  0,  0,  0,  0,  0},
	{50, 50, 50, 50, 50, 50, 50, 50},
	{10, 10, 20, 30, 30, 20, 10, 10},
	{ 5,  5, 10, 25, 25, 10,  5,  5},
	{ 0,  0,  0, 20, 20,  0,  0,  0},
	{ 5, -5,-10,  0,  0,-10, -5,  5},
	{ 5, 10, 10,-20,-20, 10, 10,  5},
	{ 0,  0,  0,  0,  0,  0,  0,  0}
};
static const int knightTable[8][8] = {
	{-50,-40,-30,-30,-30,-30,-40,-50},
	{-40,-20,  0,  0,  0,  0,-20,-40},
	{-30,  0, 10, 15, 15, 10,  0,-30},
	{-30,  5, 15, 20, 20, 15,  5,-30},
	{-30,  0, 15, 20, 20, 15,  0,-30},
	{-30,  5, 10, 15, 15, 10,  5,-30},
	{-40,-20,  0,  5,  5,  0,-20,-40},
	{-50,-40,-30,-30,-30,-30,-40,-50}
};
static const int bishopTable[8][8] = {
	{-20,-10,-10,-10,-10,-10,-10,-20},
	{-10,  0,  0,  0,  0,  0,  0,-10},
	{-10,  0, 10, 10, 10, 10,  0,-10},
	{-10,  5,  5, 10, 10,  5,  5,-10},
	{-10,  0,  5, 10, 10,  5,  0,-10},
	{-10, 10, 10, 10, 10, 10, 10,-10},
	{-10,  5,  0,  0,  0,  0,  5,-10},
	{-20,-10,-10,-10,-10,-10,-10,-20}
};
static const int rookTable[8][8] = {
	{ 0,  0,  0,  0,  0,  0,  0,  0},
	{ 5, 10, 10, 10, 10, 10, 10,  5},
	{-5,  0,  0,  0,  0,  0,  0, -5},
	{-5,  0,  0,  0,  0,  0,  0, -5},
	{-5,  0,  0,  0,  0,  0,  0, -5},
	{-5,  0,  0,  0,  0,  0,  0, -5},
	{-5,  0,  0,  0,  0,  0,  0, -5},
	{ 0,  0,  0,  5,  5,  0,  0,  0}
};
static const int queenTable[8][8] = {
	{-20,-10,-10, -5, -5,-10,-10,-20},
	{-10,  0,  0,  0,  0,  0,  0,-10},
	{-10,  0,  5,  5,  5,  5,  0,-10},
	{ -5,  0,  5,  5,  5,  5,  0, -5},
	{  0,  0,  5,  5,  5,  5,  0, -5},
	{-10,  5,  5,  5,  5,  5,  0,-10},
	{-10,  0,  5,  0,  0,  0,  0,-10},
	{-20,-10,-10, -5, -5,-10,-10,-20}
};
static const int kingTable[8][8] = {
	{-30,-40,-40,-50,-50,-40,-40,-30},
	{-30,-40,-40,-50,-50,-40,-40,-30},
	{-30,-40,-40,-50,-50,-40,-40,-30},
	{-30,-40,-40,-50,-50,-40,-40,-30},
	{-20,-30,-30,-40,-40,-30,-30,-20},
	{-10,-20,-20,-20,-20,-20,-20,-10},
	{ 20, 20,  0,  0,  0,  0, 20, 20},
	{ 20, 30, 10,  0,  0, 10, 30, 20}
};

MinimaxEngine::MinimaxEngine() {
	initStartPosition();
}

void MinimaxEngine::initStartPosition() {
	// Clear board
	for (int i = 0; i < 8; i++)
		for (int j = 0; j < 8; j++)
			board[i][j] = EMPTY_SQUARE;

	// White pieces (row 0 = rank 1)
	board[0][0] = W_ROOK;   board[0][1] = W_KNIGHT; board[0][2] = W_BISHOP; board[0][3] = W_QUEEN;
	board[0][4] = W_KING;   board[0][5] = W_BISHOP; board[0][6] = W_KNIGHT; board[0][7] = W_ROOK;
	for (int j = 0; j < 8; j++) board[1][j] = W_PAWN;

	// Black pieces
	board[7][0] = B_ROOK;   board[7][1] = B_KNIGHT; board[7][2] = B_BISHOP; board[7][3] = B_QUEEN;
	board[7][4] = B_KING;   board[7][5] = B_BISHOP; board[7][6] = B_KNIGHT; board[7][7] = B_ROOK;
	for (int j = 0; j < 8; j++) board[6][j] = B_PAWN;

	whiteToMove = true;
	castlingRights[0] = castlingRights[1] = castlingRights[2] = castlingRights[3] = true;
	enPassantCol = -1;
	enPassantRow = -1;
	moveHistory.clear();
}

bool MinimaxEngine::isWhitePiece(int piece) { return piece > 0; }
bool MinimaxEngine::isBlackPiece(int piece) { return piece < 0; }

string MinimaxEngine::squareToAlgebraic(int row, int col) {
	string s;
	s += (char)('a' + col);
	s += (char)('1' + row);
	return s;
}

void MinimaxEngine::algebraicToSquare(const string& s, int& row, int& col) {
	col = s[0] - 'a';
	row = s[1] - '1';
}

char MinimaxEngine::pieceToChar(int piece) {
	switch (piece) {
	case W_PAWN: return 'P'; case B_PAWN: return 'p';
	case W_KNIGHT: return 'N'; case B_KNIGHT: return 'n';
	case W_BISHOP: return 'B'; case B_BISHOP: return 'b';
	case W_ROOK: return 'R'; case B_ROOK: return 'r';
	case W_QUEEN: return 'Q'; case B_QUEEN: return 'q';
	case W_KING: return 'K'; case B_KING: return 'k';
	default: return ' ';
	}
}

int MinimaxEngine::charToPiece(char c) {
	switch (c) {
	case 'P': return W_PAWN; case 'p': return B_PAWN;
	case 'N': return W_KNIGHT; case 'n': return B_KNIGHT;
	case 'B': return W_BISHOP; case 'b': return B_BISHOP;
	case 'R': return W_ROOK; case 'r': return B_ROOK;
	case 'Q': return W_QUEEN; case 'q': return B_QUEEN;
	case 'K': return W_KING; case 'k': return B_KING;
	default: return EMPTY_SQUARE;
	}
}

int MinimaxEngine::getPieceValue(int piece) {
	switch (abs(piece)) {
	case 1: return PAWN_VALUE;
	case 2: return KNIGHT_VALUE;
	case 3: return BISHOP_VALUE;
	case 4: return ROOK_VALUE;
	case 5: return QUEEN_VALUE;
	case 6: return KING_VALUE;
	default: return 0;
	}
}

int MinimaxEngine::getPieceSquareBonus(int piece, int row, int col) {
	int r = isWhitePiece(piece) ? row : (7 - row);
	switch (abs(piece)) {
	case 1: return pawnTable[7 - r][col];
	case 2: return knightTable[7 - r][col];
	case 3: return bishopTable[7 - r][col];
	case 4: return rookTable[7 - r][col];
	case 5: return queenTable[7 - r][col];
	case 6: return kingTable[7 - r][col];
	default: return 0;
	}
}

int MinimaxEngine::evaluate() {
	int score = 0;
	for (int r = 0; r < 8; r++) {
		for (int c = 0; c < 8; c++) {
			int p = board[r][c];
			if (p == EMPTY_SQUARE) continue;
			int val = getPieceValue(p) + getPieceSquareBonus(p, r, c);
			score += isWhitePiece(p) ? val : -val;
		}
	}
	return score;
}

bool MinimaxEngine::isSquareAttacked(int row, int col, bool byWhite) {
	// Pawn attacks
	if (byWhite) {
		if (row > 0) {
			if (col > 0 && board[row - 1][col - 1] == W_PAWN) return true;
			if (col < 7 && board[row - 1][col + 1] == W_PAWN) return true;
		}
	} else {
		if (row < 7) {
			if (col > 0 && board[row + 1][col - 1] == B_PAWN) return true;
			if (col < 7 && board[row + 1][col + 1] == B_PAWN) return true;
		}
	}

	// Knight attacks
	int knightMoves[8][2] = {{-2,-1},{-2,1},{-1,-2},{-1,2},{1,-2},{1,2},{2,-1},{2,1}};
	int targetKnight = byWhite ? W_KNIGHT : B_KNIGHT;
	for (auto& m : knightMoves) {
		int nr = row + m[0], nc = col + m[1];
		if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8 && board[nr][nc] == targetKnight) return true;
	}

	// King attacks
	int targetKing = byWhite ? W_KING : B_KING;
	for (int dr = -1; dr <= 1; dr++) {
		for (int dc = -1; dc <= 1; dc++) {
			if (dr == 0 && dc == 0) continue;
			int nr = row + dr, nc = col + dc;
			if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8 && board[nr][nc] == targetKing) return true;
		}
	}

	// Rook/Queen (straight lines)
	int targetRook = byWhite ? W_ROOK : B_ROOK;
	int targetQueen = byWhite ? W_QUEEN : B_QUEEN;
	int straightDirs[4][2] = {{1,0},{-1,0},{0,1},{0,-1}};
	for (auto& d : straightDirs) {
		for (int i = 1; i < 8; i++) {
			int nr = row + d[0] * i, nc = col + d[1] * i;
			if (nr < 0 || nr >= 8 || nc < 0 || nc >= 8) break;
			if (board[nr][nc] != EMPTY_SQUARE) {
				if (board[nr][nc] == targetRook || board[nr][nc] == targetQueen) return true;
				break;
			}
		}
	}

	// Bishop/Queen (diagonals)
	int targetBishop = byWhite ? W_BISHOP : B_BISHOP;
	int diagDirs[4][2] = {{1,1},{1,-1},{-1,1},{-1,-1}};
	for (auto& d : diagDirs) {
		for (int i = 1; i < 8; i++) {
			int nr = row + d[0] * i, nc = col + d[1] * i;
			if (nr < 0 || nr >= 8 || nc < 0 || nc >= 8) break;
			if (board[nr][nc] != EMPTY_SQUARE) {
				if (board[nr][nc] == targetBishop || board[nr][nc] == targetQueen) return true;
				break;
			}
		}
	}

	return false;
}

bool MinimaxEngine::isInCheck(bool whiteKing) {
	for (int r = 0; r < 8; r++)
		for (int c = 0; c < 8; c++)
			if (board[r][c] == (whiteKing ? W_KING : B_KING))
				return isSquareAttacked(r, c, !whiteKing);
	return false;
}

vector<string> MinimaxEngine::generateAllPseudoLegalMoves(bool forWhite) {
	vector<string> moves;
	for (int r = 0; r < 8; r++) {
		for (int c = 0; c < 8; c++) {
			int p = board[r][c];
			if (p == EMPTY_SQUARE) continue;
			if (forWhite && !isWhitePiece(p)) continue;
			if (!forWhite && !isBlackPiece(p)) continue;

			int absp = abs(p);
			string from = squareToAlgebraic(r, c);

			if (absp == 1) { // Pawn
				int dir = forWhite ? 1 : -1;
				int startRow = forWhite ? 1 : 6;
				int promoRow = forWhite ? 7 : 0;
				// Single push
				if (r + dir >= 0 && r + dir < 8 && board[r + dir][c] == EMPTY_SQUARE) {
					if (r + dir == promoRow) {
						moves.push_back(from + squareToAlgebraic(r + dir, c) + "q");
					} else {
						moves.push_back(from + squareToAlgebraic(r + dir, c));
					}
					// Double push
					if (r == startRow && board[r + 2 * dir][c] == EMPTY_SQUARE) {
						moves.push_back(from + squareToAlgebraic(r + 2 * dir, c));
					}
				}
				// Captures
				for (int dc = -1; dc <= 1; dc += 2) {
					int nr = r + dir, nc = c + dc;
					if (nr < 0 || nr >= 8 || nc < 0 || nc >= 8) continue;
					if (board[nr][nc] != EMPTY_SQUARE && isWhitePiece(board[nr][nc]) != forWhite) {
						if (nr == promoRow) {
							moves.push_back(from + squareToAlgebraic(nr, nc) + "q");
						} else {
							moves.push_back(from + squareToAlgebraic(nr, nc));
						}
					}
					// En passant
					if (nr == enPassantRow && nc == enPassantCol) {
						moves.push_back(from + squareToAlgebraic(nr, nc));
					}
				}
			}
			else if (absp == 2) { // Knight
				int km[8][2] = {{-2,-1},{-2,1},{-1,-2},{-1,2},{1,-2},{1,2},{2,-1},{2,1}};
				for (auto& m : km) {
					int nr = r + m[0], nc = c + m[1];
					if (nr < 0 || nr >= 8 || nc < 0 || nc >= 8) continue;
					if (board[nr][nc] == EMPTY_SQUARE || isWhitePiece(board[nr][nc]) != forWhite)
						moves.push_back(from + squareToAlgebraic(nr, nc));
				}
			}
			else if (absp == 3 || absp == 4 || absp == 5) { // Bishop, Rook, Queen
				int dirs[8][2] = {{1,0},{-1,0},{0,1},{0,-1},{1,1},{1,-1},{-1,1},{-1,-1}};
				int startDir = 0, endDir = 8;
				if (absp == 4) endDir = 4;       // Rook: straight only
				if (absp == 3) startDir = 4;     // Bishop: diagonal only
				for (int d = startDir; d < endDir; d++) {
					for (int i = 1; i < 8; i++) {
						int nr = r + dirs[d][0] * i, nc = c + dirs[d][1] * i;
						if (nr < 0 || nr >= 8 || nc < 0 || nc >= 8) break;
						if (board[nr][nc] == EMPTY_SQUARE) {
							moves.push_back(from + squareToAlgebraic(nr, nc));
						} else {
							if (isWhitePiece(board[nr][nc]) != forWhite)
								moves.push_back(from + squareToAlgebraic(nr, nc));
							break;
						}
					}
				}
			}
			else if (absp == 6) { // King
				for (int dr = -1; dr <= 1; dr++) {
					for (int dc = -1; dc <= 1; dc++) {
						if (dr == 0 && dc == 0) continue;
						int nr = r + dr, nc = c + dc;
						if (nr < 0 || nr >= 8 || nc < 0 || nc >= 8) continue;
						if (board[nr][nc] == EMPTY_SQUARE || isWhitePiece(board[nr][nc]) != forWhite)
							moves.push_back(from + squareToAlgebraic(nr, nc));
					}
				}
				// Castling
				if (forWhite && r == 0 && c == 4) {
					if (castlingRights[0] && board[0][5] == 0 && board[0][6] == 0 && board[0][7] == W_ROOK
						&& !isSquareAttacked(0, 4, true) && !isSquareAttacked(0, 5, true) && !isSquareAttacked(0, 6, true))
						moves.push_back("e1g1");
					if (castlingRights[1] && board[0][3] == 0 && board[0][2] == 0 && board[0][1] == 0 && board[0][0] == W_ROOK
						&& !isSquareAttacked(0, 4, true) && !isSquareAttacked(0, 3, true) && !isSquareAttacked(0, 2, true))
						moves.push_back("e1c1");
				}
				if (!forWhite && r == 7 && c == 4) {
					if (castlingRights[2] && board[7][5] == 0 && board[7][6] == 0 && board[7][7] == B_ROOK
						&& !isSquareAttacked(7, 4, false) && !isSquareAttacked(7, 5, false) && !isSquareAttacked(7, 6, false))
						moves.push_back("e8g8");
					if (castlingRights[3] && board[7][3] == 0 && board[7][2] == 0 && board[7][1] == 0 && board[7][0] == B_ROOK
						&& !isSquareAttacked(7, 4, false) && !isSquareAttacked(7, 3, false) && !isSquareAttacked(7, 2, false))
						moves.push_back("e8c8");
				}
			}
		}
	}
	return moves;
}

vector<string> MinimaxEngine::generateAllLegalMoves(bool forWhite) {
	vector<string> pseudo = generateAllPseudoLegalMoves(forWhite);
	vector<string> legal;
	for (auto& mv : pseudo) {
		MoveUndo undo;
		applyMove(mv, undo);
		if (!isInCheck(forWhite))
			legal.push_back(mv);
		undoMove(undo);
	}
	return legal;
}

void MinimaxEngine::applyMove(const string& move, MoveUndo& undo) {
	int fr, fc, tr, tc;
	algebraicToSquare(move.substr(0, 2), fr, fc);
	algebraicToSquare(move.substr(2, 2), tr, tc);

	undo.fromRow = fr; undo.fromCol = fc;
	undo.toRow = tr; undo.toCol = tc;
	undo.movedPiece = board[fr][fc];
	undo.capturedPiece = board[tr][tc];
	for (int i = 0; i < 4; i++) undo.castlingRights[i] = castlingRights[i];
	undo.enPassantCol = enPassantCol;
	undo.wasEnPassant = false;
	undo.wasCastling = false;
	undo.promotedTo = 0;

	int piece = board[fr][fc];
	int absp = abs(piece);

	// En passant capture
	if (absp == 1 && tc == enPassantCol && tr == enPassantRow) {
		undo.wasEnPassant = true;
		int capturedRow = isWhitePiece(piece) ? tr - 1 : tr + 1;
		undo.capturedPiece = board[capturedRow][tc];
		board[capturedRow][tc] = EMPTY_SQUARE;
	}

	// Update en passant state
	enPassantCol = -1;
	enPassantRow = -1;
	if (absp == 1 && abs(tr - fr) == 2) {
		enPassantCol = fc;
		enPassantRow = (fr + tr) / 2;
	}

	// Castling move
	if (absp == 6 && abs(tc - fc) == 2) {
		undo.wasCastling = true;
		if (tc == 6) { // King-side
			board[fr][5] = board[fr][7];
			board[fr][7] = EMPTY_SQUARE;
		} else { // Queen-side
			board[fr][3] = board[fr][0];
			board[fr][0] = EMPTY_SQUARE;
		}
	}

	// Move piece
	board[tr][tc] = piece;
	board[fr][fc] = EMPTY_SQUARE;

	// Promotion
	if (move.size() == 5) {
		int promoPiece = 0;
		switch (move[4]) {
		case 'q': promoPiece = isWhitePiece(piece) ? W_QUEEN : B_QUEEN; break;
		case 'r': promoPiece = isWhitePiece(piece) ? W_ROOK : B_ROOK; break;
		case 'b': promoPiece = isWhitePiece(piece) ? W_BISHOP : B_BISHOP; break;
		case 'n': promoPiece = isWhitePiece(piece) ? W_KNIGHT : B_KNIGHT; break;
		}
		board[tr][tc] = promoPiece;
		undo.promotedTo = promoPiece;
	}

	// Update castling rights
	if (piece == W_KING) { castlingRights[0] = false; castlingRights[1] = false; }
	if (piece == B_KING) { castlingRights[2] = false; castlingRights[3] = false; }
	if (fr == 0 && fc == 7) castlingRights[0] = false;
	if (fr == 0 && fc == 0) castlingRights[1] = false;
	if (fr == 7 && fc == 7) castlingRights[2] = false;
	if (fr == 7 && fc == 0) castlingRights[3] = false;
	if (tr == 0 && tc == 7) castlingRights[0] = false;
	if (tr == 0 && tc == 0) castlingRights[1] = false;
	if (tr == 7 && tc == 7) castlingRights[2] = false;
	if (tr == 7 && tc == 0) castlingRights[3] = false;

	whiteToMove = !whiteToMove;
}

void MinimaxEngine::undoMove(const MoveUndo& undo) {
	whiteToMove = !whiteToMove;
	for (int i = 0; i < 4; i++) castlingRights[i] = undo.castlingRights[i];
	enPassantCol = undo.enPassantCol;
	// Restore enPassantRow from enPassantCol
	if (enPassantCol >= 0) {
		enPassantRow = whiteToMove ? 5 : 2;
	} else {
		enPassantRow = -1;
	}

	int piece = undo.promotedTo ? undo.movedPiece : board[undo.toRow][undo.toCol];
	if (undo.promotedTo) piece = undo.movedPiece;

	board[undo.fromRow][undo.fromCol] = piece;
	board[undo.toRow][undo.toCol] = undo.wasEnPassant ? EMPTY_SQUARE : undo.capturedPiece;

	if (undo.wasEnPassant) {
		int capturedRow = isWhitePiece(piece) ? undo.toRow - 1 : undo.toRow + 1;
		board[capturedRow][undo.toCol] = undo.capturedPiece;
	}

	if (undo.wasCastling) {
		if (undo.toCol == 6) { // King-side
			board[undo.fromRow][7] = board[undo.fromRow][5];
			board[undo.fromRow][5] = EMPTY_SQUARE;
		} else { // Queen-side
			board[undo.fromRow][0] = board[undo.fromRow][3];
			board[undo.fromRow][3] = EMPTY_SQUARE;
		}
	}
}

int MinimaxEngine::minimax(int depth, int alpha, int beta, bool maximizing) {
	if (depth == 0) return evaluate();

	vector<string> moves = generateAllLegalMoves(maximizing);

	if (moves.empty()) {
		if (isInCheck(maximizing)) {
			return maximizing ? -KING_VALUE + (100 - depth) : KING_VALUE - (100 - depth);
		}
		return 0; // Stalemate
	}

	// Move ordering: captures first for better pruning
	sort(moves.begin(), moves.end(), [&](const string& a, const string& b) {
		int ra, ca, rb, cb;
		algebraicToSquare(a.substr(2, 2), ra, ca);
		algebraicToSquare(b.substr(2, 2), rb, cb);
		int va = abs(board[ra][ca]);
		int vb = abs(board[rb][cb]);
		return va > vb;
	});

	if (maximizing) {
		int maxEval = INT_MIN;
		for (auto& mv : moves) {
			MoveUndo undo;
			applyMove(mv, undo);
			int eval = minimax(depth - 1, alpha, beta, false);
			undoMove(undo);
			maxEval = max(maxEval, eval);
			alpha = max(alpha, eval);
			if (beta <= alpha) break;
		}
		return maxEval;
	} else {
		int minEval = INT_MAX;
		for (auto& mv : moves) {
			MoveUndo undo;
			applyMove(mv, undo);
			int eval = minimax(depth - 1, alpha, beta, true);
			undoMove(undo);
			minEval = min(minEval, eval);
			beta = min(beta, eval);
			if (beta <= alpha) break;
		}
		return minEval;
	}
}

vector<string> MinimaxEngine::list_all_legal_moves() {
	return generateAllLegalMoves(whiteToMove);
}

vector<string> MinimaxEngine::list_legal_moves(string position) {
	vector<string> all = list_all_legal_moves();
	vector<string> filtered;
	for (auto& m : all) {
		if (m[0] == position[0] && m[1] == position[1])
			filtered.push_back(m);
	}
	return filtered;
}

void MinimaxEngine::update_moves(string move) {
	moveHistory.push_back(move);
	MoveUndo undo;
	applyMove(move, undo);
	// We don't need to undo - this is a permanent move
}

string MinimaxEngine::FenExtracter() {
	string fen;
	for (int r = 7; r >= 0; r--) {
		int empty = 0;
		for (int c = 0; c < 8; c++) {
			if (board[r][c] == EMPTY_SQUARE) {
				empty++;
			} else {
				if (empty > 0) { fen += to_string(empty); empty = 0; }
				fen += pieceToChar(board[r][c]);
			}
		}
		if (empty > 0) fen += to_string(empty);
		if (r > 0) fen += '/';
	}
	fen += ' ';
	fen += whiteToMove ? 'w' : 'b';
	fen += ' ';
	string castling;
	if (castlingRights[0]) castling += 'K';
	if (castlingRights[1]) castling += 'Q';
	if (castlingRights[2]) castling += 'k';
	if (castlingRights[3]) castling += 'q';
	fen += castling.empty() ? "-" : castling;
	fen += ' ';
	if (enPassantCol >= 0) {
		fen += (char)('a' + enPassantCol);
		fen += (char)('1' + enPassantRow);
	} else {
		fen += '-';
	}
	fen += " 0 1";
	return fen;
}

vector<vector<char>> MinimaxEngine::BoardMaker() {
	vector<vector<char>> result(8, vector<char>(8, 'E'));
	// Output format matches Stockfish: row 0 = rank 8 (top), row 7 = rank 1 (bottom)
	for (int r = 0; r < 8; r++) {
		for (int c = 0; c < 8; c++) {
			int internalRow = 7 - r; // Convert: output row 0 = internal row 7 (rank 8)
			if (board[internalRow][c] != EMPTY_SQUARE) {
				result[r][c] = pieceToChar(board[internalRow][c]);
			}
		}
	}
	// Debug print
	for (int i = 0; i < 8; i++) {
		for (int j = 0; j < 8; j++) {
			cout << result[i][j] << " ";
		}
		cout << endl;
	}
	return result;
}

int MinimaxEngine::WinChecker(Spot sboard[8][8]) {
	vector<string> moves = generateAllLegalMoves(whiteToMove);
	if (!moves.empty()) return 0; // Game continues

	if (isInCheck(whiteToMove)) {
		// Checkmate - the side to move lost
		return whiteToMove ? 2 : 1; // 1 = white won, 2 = black won
	}
	return 3; // Stalemate
}

string MinimaxEngine::GetBestMove(int depth) {
	vector<string> moves = generateAllLegalMoves(whiteToMove);
	if (moves.empty()) return "(none)";

	string bestMove;
	int bestScore = whiteToMove ? INT_MIN : INT_MAX;

	// Move ordering for root
	sort(moves.begin(), moves.end(), [&](const string& a, const string& b) {
		int ra, ca, rb, cb;
		algebraicToSquare(a.substr(2, 2), ra, ca);
		algebraicToSquare(b.substr(2, 2), rb, cb);
		return abs(board[ra][ca]) > abs(board[rb][cb]);
	});

	for (auto& mv : moves) {
		MoveUndo undo;
		applyMove(mv, undo);
		int score = minimax(depth - 1, INT_MIN, INT_MAX, !whiteToMove);
		undoMove(undo);

		if (whiteToMove) {
			if (score > bestScore) { bestScore = score; bestMove = mv; }
		} else {
			if (score < bestScore) { bestScore = score; bestMove = mv; }
		}
	}
	return bestMove; // Return full UCI string including promotion piece if any
}

void MinimaxEngine::set_moves(const vector<string>& current_moves) {
	if (starting_fen.empty()) {
		initStartPosition();
	} else {
		loadFEN(starting_fen);
	}
	for (const string& move : current_moves) {
		update_moves(move);
	}
}

void MinimaxEngine::set_starting_fen(const string& fen) {
	starting_fen = fen;
	if (fen.empty()) {
		initStartPosition();
	} else {
		loadFEN(fen);
	}
}

void MinimaxEngine::loadFEN(const string& fen) {
	for (int i = 0; i < 8; i++)
		for (int j = 0; j < 8; j++)
			board[i][j] = EMPTY_SQUARE;

	int row = 7, col = 0;
	size_t pos = 0;
	while (pos < fen.size() && fen[pos] != ' ') {
		char c = fen[pos++];
		if (c == '/') {
			row--;
			col = 0;
		} else if (isdigit(c)) {
			col += (c - '0');
		} else {
			board[row][col++] = charToPiece(c);
		}
	}

	whiteToMove = true;
	castlingRights[0] = castlingRights[1] = castlingRights[2] = castlingRights[3] = false;
	enPassantCol = -1;
	enPassantRow = -1;
	moveHistory.clear();

	if (pos >= fen.size()) return;
	pos++; // skip space
	if (pos < fen.size()) whiteToMove = (fen[pos] == 'w');
	
	pos += 2; // skip color and space
	if (pos < fen.size() && fen[pos] != '-') {
		while (pos < fen.size() && fen[pos] != ' ') {
			if (fen[pos] == 'K') castlingRights[0] = true;
			if (fen[pos] == 'Q') castlingRights[1] = true;
			if (fen[pos] == 'k') castlingRights[2] = true;
			if (fen[pos] == 'q') castlingRights[3] = true;
			pos++;
		}
	} else {
		if (pos < fen.size() && fen[pos] == '-') pos++;
	}

	pos++; // skip space
	if (pos < fen.size() && fen[pos] != '-') {
		enPassantCol = fen[pos] - 'a';
		enPassantRow = fen[pos + 1] - '1';
	}
}

float MinimaxEngine::GetEvaluation() {
	return (float)evaluate() / 100.0f;
}

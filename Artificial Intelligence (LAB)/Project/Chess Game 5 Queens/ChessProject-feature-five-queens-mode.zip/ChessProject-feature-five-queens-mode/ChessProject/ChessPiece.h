#pragma once
#include <raylib.h>
#include <raymath.h>
#include "Settings.h"

enum Type { King, Queen, Bishop, Rook ,Knight, Pawn };

class ChessPiece
{
public:
	ChessPiece(Vector3 pos, enum Type a,bool b);

	Vector3 position;
	bool colour;
	Model model;
	BoundingBox box;
	enum Type Name;

	void CustomLoader();
	void Draw();
	void UpdateBoundingBox();
	~ChessPiece();

};
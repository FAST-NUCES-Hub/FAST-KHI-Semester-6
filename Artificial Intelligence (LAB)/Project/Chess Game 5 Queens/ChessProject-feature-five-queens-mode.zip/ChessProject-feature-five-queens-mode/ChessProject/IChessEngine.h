#pragma once
#include <vector>
#include <string>

using namespace std;

// Forward declaration to avoid circular includes
class Spot;

class IChessEngine {
public:
	virtual ~IChessEngine() = default;
	virtual vector<string> list_all_legal_moves() = 0;
	virtual vector<string> list_legal_moves(string position) = 0;
	virtual void update_moves(string move) = 0;
	virtual string FenExtracter() = 0;
	virtual vector<vector<char>> BoardMaker() = 0;
	virtual int WinChecker(Spot board[8][8]) = 0;
	virtual string GetBestMove(int depth) = 0;
	virtual void set_moves(const vector<string>& current_moves) = 0;
	virtual float GetEvaluation() = 0;
	virtual void set_starting_fen(const string& fen) = 0;
};

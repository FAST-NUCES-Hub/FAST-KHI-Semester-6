#include <raylib.h>
#include <raymath.h>
#include <cmath>
#include "Board.h"
#include "MainMenu.h"
#include <vector>
#include "Settings.h"
#define RAYGUI_IMPLEMENTATION
#include <raygui.h>

#define GUI_MENULAYOUT_IMPLEMENTATION
#include "Resources/GUI/MenuLayout.h"

#define GUI_OPTIONS_IMPLEMENTATION
#include "Resources/GUI/Options.h"

#define GUI_WINDOW_FILE_DIALOG_IMPLEMENTATION
#include "gui_window_file_dialog.h"



const int ScreenWidth = 1920;
const int ScreenHeight = 1080; 

// Static member initialization
vector<Color> Settings::Colors;
vector<string> Settings::ModelLocations;
vector<string> Settings::Styles;
int Settings::current_style;
string Settings::StockfishPath;
int Settings::EngineType;
int Settings::MinimaxDepth;
float Settings::AnimationSpeed;
float Settings::AudioVolume;
bool Settings::SoundEffects;
bool Settings::AutoPromoteToQueen;
bool Settings::EnableUndoRedo;
bool Settings::ShowMoveHistory;
bool Settings::ShowEvalBar;
bool Settings::FiveQueensMode;

int main() {
    Settings options;
    float loadingProgress = 0;
    GameState State = LoadingScreen;
    GameState NextStateAfterLoading = MenuScreen;
    int fileActionTarget = 0;
    Board* chessboard=new Board();
    InitWindow(ScreenWidth, ScreenHeight, "Testing");
    SetExitKey(0); // Prevent ESC from closing the window
    SetWindowState(FLAG_WINDOW_RESIZABLE);
    SetTargetFPS(60);
    bool running = true;
    GuiMenuLayoutState menustate = InitGuiMenuLayout();
    GuiOptionsState optionstate = InitGuiOptions();
    GuiWindowFileDialogState Filestate = InitGuiWindowFileDialog(GetWorkingDirectory());
    Camera3D camera;
    camera.position = Vector3{ 0.1f, 5.0f, 0.1f };
    camera.target = Vector3{ 1.0f, 3.5f, 1.0f };
    camera.up = Vector3{ 0.0f, 1.0f, 0.0f };
    camera.fovy = 90.0f;
    camera.projection = CAMERA_PERSPECTIVE;
    vector <string> moves;
    GuiLoadStyle(options.Styles[options.current_style].c_str());
    

    while (running) {
    //ScreenWidth = GetScreenWidth();
    //ScreenHeight = GetScreenHeight();
    switch (State)
    {
    case LoadingScreen:
    {

        while (loadingProgress < 100 && chessboard->Init(loadingProgress) ) {
            BeginDrawing();
            ClearBackground(RAYWHITE);

            // Render loading progress bar
            DrawRectangle(100, GetScreenHeight() / 2 - 25, (int)(loadingProgress * (GetScreenWidth() - 200) / 100), 50, GREEN);
            DrawRectangleLines(100, GetScreenHeight() / 2 - 25, GetScreenWidth() - 200, 50, DARKGRAY);
            
            int dotCount = (int)(GetTime() * 3) % 4;
            std::string loadingText = "Loading" + std::string(dotCount, '.');
            std::string percentageText = TextFormat(" %d%%", (int)loadingProgress);
            std::string fullText = loadingText + percentageText;
            
            DrawText(fullText.c_str(), GetScreenWidth() / 2 - MeasureText(fullText.c_str(), 20) / 2, GetScreenHeight() / 2 + 50, 20, DARKGRAY);

            EndDrawing();
        }

        
        State = NextStateAfterLoading;
    }
        break;
    case MenuScreen:
    {
        BeginDrawing();
        ClearBackground(GetColor(GuiGetStyle(DEFAULT, BACKGROUND_COLOR)));
        
        GuiMenuLayout(&menustate,State);
        EndDrawing();

        if (WindowShouldClose() || !menustate.WindowBox000Active) {
            running=false;
            break;
        }
        // Check if transitioning to GameScreen
        if (State == GameScreen) {
            chessboard->InitEngine();
            chessboard->isAIMode = (menustate.ToggleGroup004Active == 1);
            if (Settings::FiveQueensMode) {
                string fen = Board::GenerateFiveQueensFen();
                chessboard->engine->set_starting_fen(fen);
                chessboard->ApplyMovesToCurrentIndex();
            }
        }
    }
        break;
    case GameScreen:
    {
        

        
        


        
            if (WindowShouldClose()) {
                running = false;
                break;
            }

            // ESC key opens pause screen
            if (IsKeyPressed(KEY_ESCAPE)) {
                State = PauseScreen;
                break;
            }

            // Undo/Redo input
            if (IsKeyPressed(KEY_LEFT) || (IsKeyPressed(KEY_Z) && (IsKeyDown(KEY_LEFT_CONTROL) || IsKeyDown(KEY_RIGHT_CONTROL)))) {
                chessboard->UndoMove();
            }
            if (IsKeyPressed(KEY_RIGHT) || (IsKeyPressed(KEY_Y) && (IsKeyDown(KEY_LEFT_CONTROL) || IsKeyDown(KEY_RIGHT_CONTROL)))) {
                chessboard->RedoMove();
            }

            BeginDrawing();
            ClearBackground(LIGHTGRAY);
            BeginMode3D(camera);
            //cout << camera.target.x << " " << camera.target.y << " " << camera.target.z << " " << endl;

            if (IsCursorHidden()) UpdateCamera(&camera, CAMERA_FREE);
            if (IsMouseButtonPressed(MOUSE_BUTTON_RIGHT))
            {
                if (IsCursorHidden()) EnableCursor();
                else DisableCursor();
            }


            chessboard->DrawBoard();

            Ray SelectRay = GetMouseRay(GetMousePosition(), camera);
            //(SelectRay, RED);
            RayCollision checker = { 0 };
            chessboard->Selecter(SelectRay, checker);
            chessboard->currentpiece.Working();
            if (chessboard->currentpiece.IsSelected()) {
                moves = chessboard->DrawLegalMoves();
                chessboard->MakeMove(SelectRay, checker, moves);
            }

            if (chessboard->isPromotionPending) {
                State = PromotionScreen;
            }

            // AI auto-play
            chessboard->AIMove();
             
            /*
            chessboard.MovePiece(SelectRay, checker);
            chessboard.WinChecker();
            */

            DrawGrid(20, 1.0f);

            EndMode3D();

            if (Settings::ShowEvalBar) {
                float eval = chessboard->engine->GetEvaluation();
                float clampedEval = eval;
                if (clampedEval > 10.0f) clampedEval = 10.0f;
                if (clampedEval < -10.0f) clampedEval = -10.0f;
                float whitePercent = (clampedEval + 10.0f) / 20.0f;
                
                int barWidth = 30;
                int barHeight = ScreenHeight - 100;
                int barX = 20;
                int barY = 50;
                
                DrawRectangle(barX, barY, barWidth, barHeight * (1.0f - whitePercent), DARKGRAY);
                DrawRectangle(barX, barY + barHeight * (1.0f - whitePercent), barWidth, barHeight * whitePercent, RAYWHITE);
                DrawRectangleLines(barX, barY, barWidth, barHeight, BLACK);
                
                string evalStr = TextFormat("%.1f", eval);
                DrawText(evalStr.c_str(), barX + 35, barY + barHeight / 2, 20, BLACK);
            }

            if (Settings::ShowMoveHistory) {
                int panelWidth = 200;
                int panelHeight = ScreenHeight - 100;
                int panelX = ScreenWidth - panelWidth - 20;
                int panelY = 50;
                
                DrawRectangle(panelX, panelY, panelWidth, panelHeight, Fade(LIGHTGRAY, 0.8f));
                DrawRectangleLines(panelX, panelY, panelWidth, panelHeight, DARKGRAY);
                DrawText("Move History", panelX + 10, panelY + 10, 20, BLACK);
                
                int yOffset = panelY + 40;
                int startIdx = 0;
                int maxMovesOnScreen = (panelHeight - 50) / 20;
                if (chessboard->currentMoveIndex > maxMovesOnScreen) {
                    startIdx = chessboard->currentMoveIndex - maxMovesOnScreen;
                    if (startIdx % 2 != 0) startIdx--; 
                }
                
                for (int i = startIdx; i < chessboard->currentMoveIndex; i++) {
                    string moveStr = chessboard->fullMoveHistory[i];
                    if (i % 2 == 0) {
                        string num = to_string(i / 2 + 1) + ".";
                        DrawText(num.c_str(), panelX + 10, yOffset, 20, DARKGRAY);
                        DrawText(moveStr.c_str(), panelX + 50, yOffset, 20, BLACK);
                        if (i == chessboard->currentMoveIndex - 1) yOffset += 20; // Last move was white
                    } else {
                        DrawText(moveStr.c_str(), panelX + 120, yOffset, 20, BLACK);
                        yOffset += 20;
                    }
                }
            }

            DrawFPS(10, 10);

            EndDrawing();

            if (chessboard->winStatus != 0 && !chessboard->anim.active) {
                State = WinningScreen;
            }
        
    }
        break;
    
    
    
    
    case SettingsScreen:
        BeginDrawing();
        ClearBackground(GetColor(GuiGetStyle(DEFAULT, BACKGROUND_COLOR)));
        GuiOptions(&optionstate, options, State);
        EndDrawing();
        break;

    case WinningScreen:
    {
        BeginDrawing();
        ClearBackground(GetColor(GuiGetStyle(DEFAULT, BACKGROUND_COLOR)));

        string winText;
        if (chessboard->winStatus == 1) winText = "White Won!";
        else if (chessboard->winStatus == 2) winText = "Black Won!";
        else if (chessboard->winStatus == 3) winText = "Stalemate!";

        int textWidth = MeasureText(winText.c_str(), 40);
        DrawText(winText.c_str(), ScreenWidth / 2 - textWidth / 2, ScreenHeight / 2 - 100, 40, DARKGRAY);

        if (GuiButton({ (float)ScreenWidth / 2 - 100, (float)ScreenHeight / 2, 200, 50 }, "New Game")) {
            delete chessboard;
            chessboard = new Board();
            loadingProgress = 0;
            NextStateAfterLoading = GameScreen;
            State = LoadingScreen;
        }

        if (GuiButton({ (float)ScreenWidth / 2 - 100, (float)ScreenHeight / 2 + 60, 200, 50 }, "Main Menu")) {
            delete chessboard;
            chessboard = new Board();
            loadingProgress = 0;
            NextStateAfterLoading = MenuScreen;
            State = LoadingScreen;
        }

        EndDrawing();
        
        if (WindowShouldClose()) {
            running = false;
        }
        break;
    }

    case PauseScreen:
    {
        BeginDrawing();
        ClearBackground(GetColor(GuiGetStyle(DEFAULT, BACKGROUND_COLOR)));

        int textWidth = MeasureText("Paused", 40);
        DrawText("Paused", ScreenWidth / 2 - textWidth / 2, ScreenHeight / 2 - 250, 40, DARKGRAY);

        if (GuiButton({ (float)ScreenWidth / 2 - 100, (float)ScreenHeight / 2 - 150, 200, 50 }, "Resume")) {
            State = GameScreen;
        }
        
        if (GuiButton({ (float)ScreenWidth / 2 - 100, (float)ScreenHeight / 2 - 80, 200, 50 }, "Save Game")) {
            fileActionTarget = 1;
            State = FileSelectionScreen;
        }
        
        if (GuiButton({ (float)ScreenWidth / 2 - 100, (float)ScreenHeight / 2 - 10, 200, 50 }, "Load Game")) {
            fileActionTarget = 2;
            State = FileSelectionScreen;
        }
        
        if (GuiButton({ (float)ScreenWidth / 2 - 100, (float)ScreenHeight / 2 + 60, 200, 50 }, "Export PGN")) {
            fileActionTarget = 3;
            State = FileSelectionScreen;
        }

        if (GuiButton({ (float)ScreenWidth / 2 - 100, (float)ScreenHeight / 2 + 130, 200, 50 }, "Main Menu")) {
            delete chessboard;
            chessboard = new Board();
            loadingProgress = 0;
            NextStateAfterLoading = MenuScreen;
            State = LoadingScreen;
        }

        EndDrawing();
        
        if (WindowShouldClose()) {
            running = false;
        }
        break;
    }

    case PromotionScreen:
    {
        BeginDrawing();
        ClearBackground(LIGHTGRAY);
        BeginMode3D(camera);
        chessboard->DrawBoard();
        DrawGrid(20, 1.0f);
        EndMode3D();

        DrawRectangle(0, 0, ScreenWidth, ScreenHeight, Fade(BLACK, 0.6f));
        int textWidth = MeasureText("Choose Promotion Piece", 40);
        DrawText("Choose Promotion Piece", ScreenWidth / 2 - textWidth / 2, ScreenHeight / 2 - 150, 40, RAYWHITE);

        if (GuiButton({ (float)ScreenWidth / 2 - 100, (float)ScreenHeight / 2 - 50, 200, 50 }, "Queen")) {
            chessboard->CompletePromotion('q');
            State = GameScreen;
        }
        if (GuiButton({ (float)ScreenWidth / 2 - 100, (float)ScreenHeight / 2 + 10, 200, 50 }, "Rook")) {
            chessboard->CompletePromotion('r');
            State = GameScreen;
        }
        if (GuiButton({ (float)ScreenWidth / 2 - 100, (float)ScreenHeight / 2 + 70, 200, 50 }, "Bishop")) {
            chessboard->CompletePromotion('b');
            State = GameScreen;
        }
        if (GuiButton({ (float)ScreenWidth / 2 - 100, (float)ScreenHeight / 2 + 130, 200, 50 }, "Knight")) {
            chessboard->CompletePromotion('n');
            State = GameScreen;
        }

        EndDrawing();
        
        if (WindowShouldClose()) {
            running = false;
        }
        break;
    }




    case FileSelectionScreen:
    {
        BeginDrawing();
        ClearBackground(GetColor(GuiGetStyle(DEFAULT, BACKGROUND_COLOR)));
        if (Filestate.windowActive) {
            GuiWindowFileDialog(&Filestate);
        }
        else {
            string selectedPath = string(Filestate.dirPathText) + "/" + string(Filestate.fileNameText);
            
            if (fileActionTarget == 0) {
                bool temp = false;
                Type temp2 = static_cast<Type>((int)((float)optionstate.ListViewModelsActive / 2));
                if (optionstate.ListViewModelsActive % 2 == 0) {
                    temp = true;
                }

                for (int i = 0; i < 8; i++) {
                    for (int j = 0; j < 8; j++) {
                        if (chessboard->board[i][j].piece != nullptr) {
                            if (chessboard->board[i][j].piece->colour == temp && chessboard->board[i][j].piece->Name == temp2) {
                                delete chessboard->board[i][j].piece;
                                chessboard->board[i][j].piece = nullptr;
                            }
                        }
                    }
                }

                options.ModelLocations[optionstate.ListViewModelsActive] = selectedPath;
                chessboard->UpdateChessboard();
                options.SaveSettingsToFile();
                State = SettingsScreen;
            } else if (fileActionTarget == 1) {
                chessboard->SaveGame(selectedPath);
                State = PauseScreen;
            } else if (fileActionTarget == 2) {
                chessboard->LoadGame(selectedPath);
                State = GameScreen;
            } else if (fileActionTarget == 3) {
                chessboard->ExportPGN(selectedPath);
                State = PauseScreen;
            }
            
            Filestate.windowActive = true;
            fileActionTarget = 0; // reset
        }
        EndDrawing();
        break;
    }

    default:
        break;
    }
    
    }
    CloseWindow();


     
    return 0;
}

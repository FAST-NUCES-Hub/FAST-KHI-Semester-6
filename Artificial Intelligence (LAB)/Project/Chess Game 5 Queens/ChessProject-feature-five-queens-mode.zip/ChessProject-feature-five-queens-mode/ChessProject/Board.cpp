#include "Board.h"
#include "Spot.h"
#include "ChessPiece.h"
#include "Stockfish.h"
#include "MinimaxEngine.h"
#include <fstream>
#include <sstream>

//Old Constructor Used to Load everything in sync but took too long

/*
Board::Board() {
    bool color = false;
    // Initialize the board with 8x8 spots
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            Vector3 position = { static_cast<float>(i+0.5f), 0.5f, static_cast<float>(j+0.5f) };
            ChessPiece* piece = nullptr;
            if (j!=0) {
                if (color) {
                    color = false;
                }
                else {
                    color = true;
                }
            }

            // Determine the piece and color based on the position
            if (i == 0) {
                // Second row for white pieces
                switch (j) {
                case 0: piece = new ChessPiece(position, Rook, true); break;
                case 1: piece = new ChessPiece(position, Knight, true); break;
                case 2: piece = new ChessPiece(position, Bishop, true); break;
                case 3: piece = new ChessPiece(position, Queen, true); break;
                case 4: piece = new ChessPiece(position, King, true); break;
                case 5: piece = new ChessPiece(position, Bishop, true); break;
                case 6: piece = new ChessPiece(position, Knight, true); break;
                case 7: piece = new ChessPiece(position, Rook, true); break;
                }
            }
            else if (i == 7) {
                // Seventh row for black pieces
                switch (j) {
                case 0: piece = new ChessPiece(position, Rook, false); break;
                case 1: piece = new ChessPiece(position, Knight, false); break;
                case 2: piece = new ChessPiece(position, Bishop, false); break;
                case 3: piece = new ChessPiece(position, Queen, false); break;
                case 4: piece = new ChessPiece(position, King, false); break;
                case 5: piece = new ChessPiece(position, Bishop, false); break;
                case 6: piece = new ChessPiece(position, Knight, false); break;
                case 7: piece = new ChessPiece(position, Rook, false); break;
                }
            }
            else if (i == 1 || i == 6) {
                // First and last rows for pawns
                piece = new ChessPiece(position, Pawn, (i == 1)? true: false);
            }

            // Create a new Spot with the piece and add it to the board
            position.y = position.y - 0.5;
            board[i][j] = Spot(position, piece, color);
            
        }
    }
}
*/




Board::Board()
{
	engine = nullptr;
	isAIMode = false;
	whiteTurn = true;
    anim.active = false;
    winStatus = 0;
    isPromotionPending = false;
    currentMoveIndex = 0;
    fullMoveHistory.clear();
}

Board::~Board()
{
	if (engine) delete engine;
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            if (board[i][j].piece != nullptr) {
                delete board[i][j].piece;
                board[i][j].piece = nullptr;
            }
        }
    }
}

void Board::InitEngine()
{
	if (engine) delete engine;
	if (Settings::EngineType == 0)
		engine = new Stockfish();
	else
		engine = new MinimaxEngine();
	whiteTurn = true;
    anim.active = false;
    winStatus = 0;
    isPromotionPending = false;
    currentMoveIndex = 0;
    fullMoveHistory.clear();
}

string Board::GenerateFiveQueensFen() {
    char boardArray[8][8] = {
        {'r','n','b','q','k','b','n','r'},
        {'p','p','p','p','p','p','p','p'},
        {' ',' ',' ',' ',' ',' ',' ',' '},
        {' ',' ',' ',' ',' ',' ',' ',' '},
        {' ',' ',' ',' ',' ',' ',' ',' '},
        {' ',' ',' ',' ',' ',' ',' ',' '},
        {'P','P','P','P','P','P','P','P'},
        {'R','N','B','Q','K','B','N','R'}
    };
    
    vector<pair<int, int>> whiteEligible;
    for (int r = 6; r <= 7; r++) {
        for (int c = 0; c < 8; c++) {
            if (r == 7 && (c == 3 || c == 4)) continue;
            whiteEligible.push_back({r, c});
        }
    }
    int wIdx = GetRandomValue(0, whiteEligible.size() - 1);
    boardArray[whiteEligible[wIdx].first][whiteEligible[wIdx].second] = 'Q';
    
    vector<pair<int, int>> blackEligible;
    for (int r = 0; r <= 1; r++) {
        for (int c = 0; c < 8; c++) {
            if (r == 0 && (c == 3 || c == 4)) continue;
            blackEligible.push_back({r, c});
        }
    }
    int bIdx = GetRandomValue(0, blackEligible.size() - 1);
    boardArray[blackEligible[bIdx].first][blackEligible[bIdx].second] = 'q';
    
    vector<pair<int, int>> emptyEligible;
    for (int r = 2; r <= 5; r++) {
        for (int c = 0; c < 8; c++) {
            emptyEligible.push_back({r, c});
        }
    }
    int eIdx = GetRandomValue(0, emptyEligible.size() - 1);
    char fifthQ = (GetRandomValue(0, 1) == 0) ? 'Q' : 'q';
    boardArray[emptyEligible[eIdx].first][emptyEligible[eIdx].second] = fifthQ;
    
    string fen = "";
    for (int r = 0; r < 8; r++) {
        int emptyCount = 0;
        for (int c = 0; c < 8; c++) {
            if (boardArray[r][c] == ' ') {
                emptyCount++;
            } else {
                if (emptyCount > 0) {
                    fen += to_string(emptyCount);
                    emptyCount = 0;
                }
                fen += boardArray[r][c];
            }
        }
        if (emptyCount > 0) fen += to_string(emptyCount);
        if (r < 7) fen += "/";
    }
    fen += " w KQkq - 0 1";
    return fen;
}

bool Board::Init(float& progress)
{
    static int i = 0;
    static int j = 0;
    static bool color = false;

    if (progress == 0.0f) {
        i = 0;
        j = 0;
        color = false;
    }

    if (i < 8 && j < 8) {
        Vector3 position = { static_cast<float>(i + 0.5f), 0.5f, static_cast<float>(j + 0.5f) };
        ChessPiece* piece = nullptr;
        if (j != 0) {
            if (color) {
                color = false;
            }
            else {
                color = true;
            }
        }

        // Determine the piece and color based on the position
        if (i == 0) {
            // Second row for white pieces
            switch (j) {
            case 0: piece = new ChessPiece(position, Rook, true); break;
            case 1: piece = new ChessPiece(position, Knight, true); break;
            case 2: piece = new ChessPiece(position, Bishop, true); break;
            case 3: piece = new ChessPiece(position, Queen, true); break;
            case 4: piece = new ChessPiece(position, King, true); break;
            case 5: piece = new ChessPiece(position, Bishop, true); break;
            case 6: piece = new ChessPiece(position, Knight, true); break;
            case 7: piece = new ChessPiece(position, Rook, true); break;
            }
        }
        else if (i == 7) {
            // Seventh row for black pieces
            switch (j) {
            case 0: piece = new ChessPiece(position, Rook, false); break;
            case 1: piece = new ChessPiece(position, Knight, false); break;
            case 2: piece = new ChessPiece(position, Bishop, false); break;
            case 3: piece = new ChessPiece(position, Queen, false); break;
            case 4: piece = new ChessPiece(position, King, false); break;
            case 5: piece = new ChessPiece(position, Bishop, false); break;
            case 6: piece = new ChessPiece(position, Knight, false); break;
            case 7: piece = new ChessPiece(position, Rook, false); break;
            }
        }
        else if (i == 1 || i == 6) {
            // First and last rows for pawns
            piece = new ChessPiece(position, Pawn, (i == 1) ? true : false);
        }
        progress += 1.5625;
        // Create a new Spot with the piece and add it to the board
        position.y = position.y - 0.5;
        board[i][j] = Spot(position, piece, color);
        
        //loop logic

        if (j < 7) {
            j++;
        }
        else {
            j = 0;
            i++;
            return true;
        }



        return true;
    }
    return false;
}

void Board::DrawBoard()
{
    if (anim.active) {
        float dt = GetFrameTime();
        if (dt > 0.1f) dt = 0.1f; // Clamp to prevent huge skips when thread blocks (like after AI thinking)
        
        anim.progress += dt * Settings::AnimationSpeed;
        if (anim.progress >= 1.0f) {
            anim.progress = 1.0f;
            anim.active = false;
            
            // Delete captured piece if present before finalizing
            if (board[anim.endRow][anim.endCol].piece != nullptr) {
                delete board[anim.endRow][anim.endCol].piece;
            }
            
            // Place animated piece into target square
            board[anim.endRow][anim.endCol].piece = anim.piece;
            anim.piece->position = anim.endPos;
            anim.piece->UpdateBoundingBox();
            
            // Complete state update
            UpdateChessboard();
            whiteTurn = anim.isWhiteTurnNext;
            winStatus = engine->WinChecker(board);
        } else {
            // Interpolate position
            anim.piece->position = Vector3Lerp(anim.startPos, anim.endPos, anim.progress);
        }
    }

    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            board[i][j].Draw();
            if (board[i][j].piece != nullptr) {
                board[i][j].DrawPiece();
            }
        }
    }

    // Draw animating piece on top
    if (anim.active && anim.piece != nullptr) {
        anim.piece->Draw();
    }
}

void Board::Selecter(Ray SelectRay, RayCollision checker)
{
    if (anim.active) return;
    if (!IsCursorHidden()) {
        float closestDistance = 999999.0f;
        int hitI = -1;
        int hitJ = -1;

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                RayCollision col = GetRayCollisionBox(SelectRay, board[i][j].spotbox);
                if (col.hit && col.distance < closestDistance) {
                    closestDistance = col.distance;
                    hitI = i;
                    hitJ = j;
                }
            }
        }

        if (hitI != -1 && hitJ != -1) {
            int i = hitI;
            int j = hitJ;
            if (currentpiece.IsSelected() && currentpiece.Validate(i, j) && IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
                currentpiece.ToggleSelected();
            } else if (!currentpiece.IsSelected() && board[i][j].piece != nullptr) {
                DrawCube(board[i][j].position, 1.0f, 1.0f, 1.0f, Settings::Colors[0]);
                if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
                    currentpiece.SetSelectedPiece(i, j, &board[i][j]);
                }
            }
        }
    }
}
vector <string> Board::DrawLegalMoves()
{

    string query;
    query.push_back(currentpiece.col + 'a' );
    query.push_back(currentpiece.row + '1' );
    vector <string> legalmoves = engine->list_legal_moves(query);
    for (int i = 0; i < legalmoves.size(); i++) {
        legalmoves[i] = legalmoves[i].substr(2, 2);
    }
    for (int i = 0; i < legalmoves.size(); i++) {
        DrawCube(board[legalmoves[i][1] - '1'][legalmoves[i][0] - 'a'].position, 1.0f, 1.0f, 1.0f, Settings::Colors[2]);
    }
    return legalmoves;
}
void Board::MakeMove(Ray SelectRay, RayCollision checker, vector <string> moves)
{
    if (anim.active) return;
    if (!IsCursorHidden()) {
        float closestDistance = 999999.0f;
        int hitI = -1;
        int hitJ = -1;

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                RayCollision col = GetRayCollisionBox(SelectRay, board[i][j].spotbox);
                if (col.hit && col.distance < closestDistance) {
                    closestDistance = col.distance;
                    hitI = i;
                    hitJ = j;
                }
            }
        }

        if (hitI != -1 && hitJ != -1) {
            int i = hitI;
            int j = hitJ;
            for (auto a : moves) {
                int row = a[1] - '1';
                int col = a[0] - 'a';
                if (i == row && j == col) {
                    DrawCube(board[i][j].position, 1.0f, 1.0f, 1.0f, Settings::Colors[3]);
                    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && !currentpiece.Validate(i,j)) {
                        DoMove(row, col);
                        currentpiece.ToggleSelected();
                        break;
                    }
                }
            }
        }
    }
}
void Board::DoMove(int row, int col)
{
    string line;
    line.push_back(currentpiece.col + 'a');
    line.push_back(currentpiece.row + '1');
    line.push_back(col + 'a');
    line.push_back(row + '1');

    if (currentpiece.current != nullptr && currentpiece.current->piece != nullptr && currentpiece.current->piece->Name == Pawn) {
        if (row == 0 || row == 7) {
            if (Settings::AutoPromoteToQueen) {
                line.push_back('q'); // Auto-promote to Queen
            } else {
                pendingPromotionMove = line;
                isPromotionPending = true;
                return; // Wait for user choice
            }
        }
    }

    if (currentMoveIndex < fullMoveHistory.size()) {
        fullMoveHistory.erase(fullMoveHistory.begin() + currentMoveIndex, fullMoveHistory.end());
    }
    fullMoveHistory.push_back(line);
    currentMoveIndex++;

    engine->update_moves(line);
    StartAnimation(line, false);
}
void Board::UpdateChessboard()
{
    vector<vector <char>>internal_board;
    internal_board = engine->BoardMaker();
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            switch (internal_board[i][j])
            {
            case 'E':
                if (board[7 - i][j].piece != nullptr) {
                    delete board[7 - i][j].piece;
                    board[7 - i][j].piece = nullptr;
                    break;
                }
                break;
            case 'P':
                if ((board[7 - i][j].piece != nullptr) && (board[7 - i][j].piece->Name != Pawn || !board[7 - i][j].piece->colour)) {
                    Vector3 pos = board[7 - i][j].piece->position;
                    delete board[7 - i][j].piece;
                    board[7 - i][j].piece = new ChessPiece(pos, Pawn, true);
                    break;
                }
                else if (board[7 - i][j].piece == nullptr) {
                    Vector3 pos = board[7 - i][j].position;
                    pos.y = pos.y + 0.5f;
                    board[7 - i][j].piece = new ChessPiece(pos, Pawn, true);
                }
                break;

            case 'R':
                if ((board[7 - i][j].piece != nullptr) && (board[7 - i][j].piece->Name != Rook || !board[7 - i][j].piece->colour)) {
                    Vector3 pos = board[7 - i][j].piece->position;
                    delete board[7 - i][j].piece;
                    board[7 - i][j].piece = new ChessPiece(pos, Rook, true);
                    break;
                }
                else if (board[7 - i][j].piece == nullptr) {
                    Vector3 pos = board[7 - i][j].position;
                    pos.y = pos.y + 0.5f;
                    board[7 - i][j].piece = new ChessPiece(pos, Rook, true);
                }
                break;
            case 'N':
                if ((board[7 - i][j].piece != nullptr) && (board[7 - i][j].piece->Name != Knight || !board[7 - i][j].piece->colour)) {
                    Vector3 pos = board[7 - i][j].piece->position;
                    delete board[7 - i][j].piece;
                    board[7 - i][j].piece = new ChessPiece(pos, Knight, true);
                    break;
                }
                else if (board[7 - i][j].piece == nullptr) {
                    Vector3 pos = board[7 - i][j].position;
                    pos.y = pos.y + 0.5f;
                    board[7 - i][j].piece = new ChessPiece(pos, Knight, true);
                }
                break;
            case 'K':
                if ((board[7 - i][j].piece != nullptr) && (board[7 - i][j].piece->Name != King || !board[7 - i][j].piece->colour)) {
                    Vector3 pos = board[7 - i][j].piece->position;
                    delete board[7 - i][j].piece;
                    board[7 - i][j].piece = new ChessPiece(pos, King, true);
                    break;
                }
                else if (board[7 - i][j].piece == nullptr) {
                    Vector3 pos = board[7 - i][j].position;
                    pos.y = pos.y + 0.5f;
                    board[7 - i][j].piece = new ChessPiece(pos, King, true);
                }
                break;
            case 'Q':
                if ((board[7 - i][j].piece != nullptr) && (board[7 - i][j].piece->Name != Queen || !board[7 - i][j].piece->colour)) {
                    Vector3 pos = board[7 - i][j].piece->position;
                    delete board[7 - i][j].piece;
                    board[7 - i][j].piece = new ChessPiece(pos, Queen, true);
                    break;
                }
                else if (board[7 - i][j].piece == nullptr) {
                    Vector3 pos = board[7 - i][j].position;
                    pos.y = pos.y + 0.5f;
                    board[7 - i][j].piece = new ChessPiece(pos, Queen, true);
                }
                break;
            case 'B':
                if ((board[7 - i][j].piece != nullptr) && (board[7 - i][j].piece->Name != Bishop || !board[7 - i][j].piece->colour)) {
                    Vector3 pos = board[7 - i][j].piece->position;
                    delete board[7 - i][j].piece;
                    board[7 - i][j].piece = new ChessPiece(pos, Bishop, true);
                    break;
                }
                else if (board[7 - i][j].piece == nullptr) {
                    Vector3 pos = board[7 - i][j].position;
                    pos.y = pos.y + 0.5f;
                    board[7 - i][j].piece = new ChessPiece(pos, Bishop, true);
                }
                break;
            case 'r':
                if ((board[7 - i][j].piece != nullptr) && (board[7 - i][j].piece->Name != Rook || board[7 - i][j].piece->colour)) {
                    Vector3 pos = board[7 - i][j].piece->position;
                    delete board[7 - i][j].piece;
                    board[7 - i][j].piece = new ChessPiece(pos, Rook, false);
                    break;
                }
                else if (board[7 - i][j].piece == nullptr) {
                    Vector3 pos = board[7 - i][j].position;
                    pos.y = pos.y + 0.5f;
                    board[7 - i][j].piece = new ChessPiece(pos, Rook, false);
                }
                break;
            case 'n':
                if ((board[7 - i][j].piece != nullptr) && (board[7 - i][j].piece->Name != Knight || board[7 - i][j].piece->colour)) {
                    Vector3 pos = board[7 - i][j].piece->position;
                    delete board[7 - i][j].piece;
                    board[7 - i][j].piece = new ChessPiece(pos, Knight, false);
                    break;
                }
                else if (board[7 - i][j].piece == nullptr) {
                    Vector3 pos = board[7 - i][j].position;
                    pos.y = pos.y + 0.5f;
                    board[7 - i][j].piece = new ChessPiece(pos, Knight, false);
                }
                break;
            case 'k':
                if ((board[7 - i][j].piece != nullptr) && (board[7 - i][j].piece->Name != King || board[7 - i][j].piece->colour)) {
                    Vector3 pos = board[7 - i][j].piece->position;
                    delete board[7 - i][j].piece;
                    board[7 - i][j].piece = new ChessPiece(pos, King, false);
                    break;
                }
                else if (board[7 - i][j].piece == nullptr) {
                    Vector3 pos = board[7 - i][j].position;
                    pos.y = pos.y + 0.5f;
                    board[7 - i][j].piece = new ChessPiece(pos, King, false);
                }
                break;
            case 'q':
                if ((board[7 - i][j].piece != nullptr) && (board[7 - i][j].piece->Name != Queen || board[7 - i][j].piece->colour)) {
                    Vector3 pos = board[7 - i][j].piece->position;
                    delete board[7 - i][j].piece;
                    board[7 - i][j].piece = new ChessPiece(pos, Queen, false);
                    break;
                }
                else if (board[7 - i][j].piece == nullptr) {
                    Vector3 pos = board[7 - i][j].position;
                    pos.y = pos.y + 0.5f;
                    board[7 - i][j].piece = new ChessPiece(pos, Queen, false);
                }
                break;
            case 'b':
                if ((board[7 - i][j].piece != nullptr) && (board[7 - i][j].piece->Name != Bishop || board[7 - i][j].piece->colour)) {
                    Vector3 pos = board[7 - i][j].piece->position;
                    delete board[7 - i][j].piece;
                    board[7 - i][j].piece = new ChessPiece(pos, Bishop, false);
                    break;
                }
                else if (board[7 - i][j].piece == nullptr) {
                    Vector3 pos = board[7 - i][j].position;
                    pos.y = pos.y + 0.5f;
                    board[7 - i][j].piece = new ChessPiece(pos, Bishop, false);
                }
                break;
            case 'p':
                if ((board[7 - i][j].piece != nullptr) && (board[7 - i][j].piece->Name != Pawn || board[7 - i][j].piece->colour)) {
                    Vector3 pos = board[7 - i][j].piece->position;
                    delete board[7 - i][j].piece;
                    board[7 - i][j].piece = new ChessPiece(pos, Pawn, false);
                    break;
                }
                else if (board[7 - i][j].piece == nullptr) {
                    Vector3 pos = board[7 - i][j].position;
                    pos.y = pos.y + 0.5f;
                    board[7 - i][j].piece = new ChessPiece(pos, Pawn, false);
                }
                break;
            default:
                break;
            }
        }
    }
}

/*


void Board::MovePiece(Ray ray, RayCollision check)
{
    if (currentpiece.IsSelected() && !IsCursorHidden()) {

            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) {
                    check = GetRayCollisionBox(ray, board[i][j].spotbox);
                    if (check.hit) {
                        DrawCube(board[i][j].position, 1.0f, 1.0f, 1.0f, YELLOW);
                        if (currentpiece.IsSelected()) {
                            if (IsKeyPressed(KEY_B)) {
                                currentpiece.ToggleSelected();
                                break;
                            }
                        }
                        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
                            if (board[i][j].piece == nullptr) {
                                board[i][j].piece = currentpiece.current->piece;
                                board[i][j].piece->position = Vector3{ static_cast<float>(i + 0.5f), 0.5f, static_cast<float>(j + 0.5f) };
                                currentpiece.current->piece=nullptr;
                                currentpiece.ToggleSelected();
                            }
                            else if (board[i][j].piece != nullptr && !(currentpiece.current->piece->colour == board[i][j].piece->colour)) {
                                if (!currentpiece.Validate(i, j)) {
                                    delete board[i][j].piece;
                                    board[i][j].piece = nullptr;
                                    board[i][j].piece = currentpiece.current->piece;
                                    board[i][j].piece->position = Vector3{ static_cast<float>(i + 0.5f), 0.5f, static_cast<float>(j + 0.5f) };
                                    currentpiece.current->piece = nullptr;
                                    currentpiece.ToggleSelected();
                                    //currentpiece.current->piece->UpdateBoundingBox();
                                }
                                
                            }
                        }
                        break;
                    }
                }
                if (check.hit) {
                    break;
                }
            }
        }


 
}

void Board::WinChecker() 
{
    bool WhiteKing = false;
    bool BlackKing = false;
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            if (board[i][j].piece != nullptr) {
                if (board[i][j].piece->Name == King && board[i][j].piece->colour) {
                    WhiteKing = true;
                }
                if (board[i][j].piece->Name == King && !board[i][j].piece->colour) {
                    BlackKing = true;
                }
            }
        }
    }
    if (WhiteKing && BlackKing) {
    }
    else if (WhiteKing && !BlackKing) {
        cout << endl << endl;
        cout << "White Wins" << endl;
        exit(0);
    }
    else if (!WhiteKing && BlackKing) {
        cout << endl << endl;
        cout << "Black Wins" << endl;
        exit(0);
    }
}


*/


void Board::AIMove()
{
    if (!isAIMode || whiteTurn || anim.active) return;

    string bestMove = engine->GetBestMove(Settings::MinimaxDepth);
    if (bestMove.empty() || bestMove == "(none)") return;

    if (currentMoveIndex < fullMoveHistory.size()) {
        fullMoveHistory.erase(fullMoveHistory.begin() + currentMoveIndex, fullMoveHistory.end());
    }
    fullMoveHistory.push_back(bestMove);
    currentMoveIndex++;

    engine->update_moves(bestMove);
    StartAnimation(bestMove, true);
}

void Board::StartAnimation(string move, bool nextTurnWhite)
{
    if (move.length() < 4) return;
    
    int startCol = move[0] - 'a';
    int startRow = move[1] - '1';
    int endCol = move[2] - 'a';
    int endRow = move[3] - '1';
    
    anim.startRow = startRow;
    anim.startCol = startCol;
    anim.endRow = endRow;
    anim.endCol = endCol;
    anim.isWhiteTurnNext = nextTurnWhite;
    
    anim.piece = board[startRow][startCol].piece;
    
    // Safety check, in case of desync
    if (anim.piece == nullptr) {
        anim.active = false;
        UpdateChessboard();
        whiteTurn = nextTurnWhite;
        return;
    }

    // Detach from the board so it doesn't double-draw or get overwritten improperly
    board[startRow][startCol].piece = nullptr;
    
    anim.startPos = anim.piece->position;
    anim.endPos = board[endRow][endCol].position;
    anim.endPos.y += 0.5f; // Place piece on top of square
    
    anim.progress = 0.0f;
    anim.active = true;
}

void Board::CompletePromotion(char pieceChar) {
    if (!isPromotionPending) return;
    pendingPromotionMove.push_back(pieceChar);
    
    if (currentMoveIndex < fullMoveHistory.size()) {
        fullMoveHistory.erase(fullMoveHistory.begin() + currentMoveIndex, fullMoveHistory.end());
    }
    fullMoveHistory.push_back(pendingPromotionMove);
    currentMoveIndex++;

    engine->update_moves(pendingPromotionMove);
    StartAnimation(pendingPromotionMove, false);
    isPromotionPending = false;
    pendingPromotionMove = "";
}

void Board::ApplyMovesToCurrentIndex() {
    vector<string> movesToApply;
    for (int i = 0; i < currentMoveIndex; ++i) {
        movesToApply.push_back(fullMoveHistory[i]);
    }
    engine->set_moves(movesToApply);
    UpdateChessboard();
    whiteTurn = (currentMoveIndex % 2 == 0);
    winStatus = engine->WinChecker(board);
    currentpiece.current = nullptr;
}

void Board::UndoMove() {
    if (Settings::EnableUndoRedo && currentMoveIndex > 0 && !anim.active) {
        currentMoveIndex--;
        ApplyMovesToCurrentIndex();
    }
}

void Board::RedoMove() {
    if (Settings::EnableUndoRedo && currentMoveIndex < fullMoveHistory.size() && !anim.active) {
        currentMoveIndex++;
        ApplyMovesToCurrentIndex();
    }
}

string Board::UciToSan(const string& uciMove) {
    return uciMove;
}

void Board::SaveGame(const string& filename) {
    ofstream file(filename);
    if (file.is_open()) {
        for (const string& move : fullMoveHistory) {
            file << move << " ";
        }
        file.close();
    }
}

void Board::LoadGame(const string& filename) {
    ifstream file(filename);
    if (file.is_open()) {
        fullMoveHistory.clear();
        string move;
        while (file >> move) {
            fullMoveHistory.push_back(move);
        }
        file.close();
        currentMoveIndex = fullMoveHistory.size();
        ApplyMovesToCurrentIndex();
    }
}

void Board::ExportPGN(const string& filename) {
    ofstream file(filename);
    if (file.is_open()) {
        file << "[Event \"Casual Game\"]\n";
        file << "[Site \"Local\"]\n";
        file << "[Date \"????.??.??\"]\n";
        file << "[Round \"1\"]\n";
        file << "[White \"Player 1\"]\n";
        file << "[Black \"Player 2\"]\n";
        file << "[Result \"*\"]\n\n";
        
        for (size_t i = 0; i < fullMoveHistory.size(); ++i) {
            if (i % 2 == 0) {
                file << (i / 2 + 1) << ". ";
            }
            file << UciToSan(fullMoveHistory[i]) << " ";
        }
        file << "*\n";
        file.close();
    }
}



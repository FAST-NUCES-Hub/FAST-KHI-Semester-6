#pragma once
#include "Spot.h"
#include "SelectedPiece.h"
#include <iostream>
#include "IChessEngine.h"

using namespace std;

struct MoveAnimation {
    bool active;
    ChessPiece* piece;
    Vector3 startPos;
    Vector3 endPos;
    float progress;
    int startRow, startCol, endRow, endCol;
    bool isWhiteTurnNext;
};

class Board
{
public:
	Spot board[8][8];
	SelectedPiece currentpiece;
	IChessEngine* engine;
	bool isAIMode;
	bool whiteTurn;
	Board();
	~Board();
	void InitEngine();
	bool Init(float& progress);
	static string GenerateFiveQueensFen();
	void DrawBoard();
	void Selecter(Ray ray,RayCollision check);
	//void MovePiece(Ray ray, RayCollision check);
	//void WinChecker();
	vector <string> DrawLegalMoves();
	void MakeMove(Ray SelectRay, RayCollision checker, vector <string> moves);
	void DoMove(int row,int col);
	void UpdateChessboard();
	void AIMove();
    void StartAnimation(string move, bool nextTurnWhite);
	MoveAnimation anim;
	int winStatus;
	bool isPromotionPending;
	string pendingPromotionMove;
	void CompletePromotion(char pieceChar);

	vector<string> fullMoveHistory;
	int currentMoveIndex;
	void UndoMove();
	void RedoMove();
	void ApplyMovesToCurrentIndex();
	
	string UciToSan(const string& uciMove);
	void SaveGame(const string& filename);
	void LoadGame(const string& filename);
	void ExportPGN(const string& filename);
};


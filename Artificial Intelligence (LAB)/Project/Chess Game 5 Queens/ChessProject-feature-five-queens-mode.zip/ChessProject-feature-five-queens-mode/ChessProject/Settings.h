#pragma once
#include <fstream>
#include <string>
#include <vector>
#include <raylib.h>
#include <iostream>

using namespace std;

class Settings {
public:
    static vector<Color> Colors;
    static vector<string> ModelLocations;
    static vector<string> Styles;
    static int current_style;
    static string StockfishPath;
    static int EngineType;      // 0 = Stockfish, 1 = Minimax
    static int MinimaxDepth;    // 1-6, default 4
    static float AnimationSpeed;// Speed multiplier for piece animations, default 3.0f
    static float AudioVolume;   // Audio volume, 0-100
    static bool SoundEffects;   // Sound effects toggle
    static bool AutoPromoteToQueen; // Bypass promotion menu and auto-promote to Queen
    static bool EnableUndoRedo; // Undo/Redo System toggle
    static bool ShowMoveHistory; // Move History UI toggle
    static bool ShowEvalBar; // Evaluation Bar UI toggle
    static bool FiveQueensMode; // Five Queens game mode toggle

    void DefaultInit() {
        // Initialize colors
        Colors = { RED, GREEN, BLUE, ORANGE, Color{ 189,125,85,255 } , Color {83,57,48,255} };

        // Initialize model locations
        ModelLocations = {
            "resources/ChessSet/LightKing.glb",
            "resources/ChessSet/DarkKing.glb",
            "resources/ChessSet/LightQueen.glb",
            "resources/ChessSet/DarkQueen.glb",
            "resources/ChessSet/LightBishop.glb",
            "resources/ChessSet/DarkBishop.glb",
            "resources/ChessSet/LightTower.glb",
            "resources/ChessSet/DarkTower.glb",
            "resources/ChessSet/LightKnight.glb",
            "resources/ChessSet/DarkKnight.glb",
            "resources/ChessSet/LightPawn.glb",
            "resources/ChessSet/DarkPawn.glb"
        };

        current_style = 0;
        Styles = { "styles/default/style_default.rgs","styles/ashes/style_ashes.rgs", "styles/bluish/style_bluish.rgs", "styles/candy/style_candy.rgs","styles/cherry/style_cherry.rgs","styles/cyber/style_cyber.rgs","styles/dark/style_dark.rgs" }; // Example styles

        // Initialize Stockfish path
        StockfishPath = "stockfish/stockfish.exe";

        // Engine settings
        EngineType = 0;     // Default: Stockfish
        MinimaxDepth = 4;   // Default depth
        AnimationSpeed = 3.0f; // Default animation speed
        AudioVolume = 50.0f;
        SoundEffects = true;
        AutoPromoteToQueen = false;
        EnableUndoRedo = true;
        ShowMoveHistory = true;
        ShowEvalBar = true;
        FiveQueensMode = false;
    }

    void LoadSettingsFromFile() {
        ifstream MyFile("Settings.bin", ios::binary);
        if (MyFile.is_open()) {
            // Read colors
            int numColors;
            MyFile.read(reinterpret_cast<char*>(&numColors), sizeof(int));
            Colors.clear();
            for (int i = 0; i < numColors; ++i) {
                Color color;
                MyFile.read(reinterpret_cast<char*>(&color), sizeof(Color));
                Colors.push_back(color);
            }

            // Read ModelLocations size and each string
            int numModels;
            MyFile.read(reinterpret_cast<char*>(&numModels), sizeof(int));
            ModelLocations.clear();
            for (int i = 0; i < numModels; ++i) {
                int size;
                MyFile.read(reinterpret_cast<char*>(&size), sizeof(int));
                char buffer[256];  // Adjust buffer size accordingly
                MyFile.read(buffer, size);
                buffer[size] = '\0';  // Null-terminate the string
                ModelLocations.emplace_back(buffer);
            }

            // Read Styles
            int numStyles;
            MyFile.read(reinterpret_cast<char*>(&numStyles), sizeof(int));
            Styles.clear();
            for (int i = 0; i < numStyles; ++i) {
                int size;
                MyFile.read(reinterpret_cast<char*>(&size), sizeof(int));
                char buffer[256];  // Adjust buffer size accordingly
                MyFile.read(buffer, size);
                buffer[size] = '\0';  // Null-terminate the string
                Styles.emplace_back(buffer);
            }

            // Read current_style
            MyFile.read(reinterpret_cast<char*>(&current_style), sizeof(int));

            // Read StockfishPath
            int stockfishPathSize;
            MyFile.read(reinterpret_cast<char*>(&stockfishPathSize), sizeof(int));
            char stockfishBuffer[512];
            MyFile.read(stockfishBuffer, stockfishPathSize);
            stockfishBuffer[stockfishPathSize] = '\0';
            StockfishPath = stockfishBuffer;

            // Read EngineType, MinimaxDepth and AnimationSpeed
            if (MyFile.read(reinterpret_cast<char*>(&EngineType), sizeof(int))) {
                MyFile.read(reinterpret_cast<char*>(&MinimaxDepth), sizeof(int));
                if (!MyFile.read(reinterpret_cast<char*>(&AnimationSpeed), sizeof(float))) {
                    AnimationSpeed = 3.0f;
                }
                if (!MyFile.read(reinterpret_cast<char*>(&AudioVolume), sizeof(float))) {
                    AudioVolume = 50.0f;
                    SoundEffects = true;
                    AutoPromoteToQueen = false;
                } else {
                    if (!MyFile.read(reinterpret_cast<char*>(&SoundEffects), sizeof(bool))) {
                        SoundEffects = true;
                        AutoPromoteToQueen = false;
                    } else if (!MyFile.read(reinterpret_cast<char*>(&AutoPromoteToQueen), sizeof(bool))) {
                        AutoPromoteToQueen = false;
                        EnableUndoRedo = true;
                        ShowMoveHistory = true;
                        ShowEvalBar = true;
                    } else if (!MyFile.read(reinterpret_cast<char*>(&EnableUndoRedo), sizeof(bool))) {
                        EnableUndoRedo = true;
                        ShowMoveHistory = true;
                        ShowEvalBar = true;
                    } else {
                        if (!MyFile.read(reinterpret_cast<char*>(&ShowMoveHistory), sizeof(bool))) ShowMoveHistory = true;
                        if (!MyFile.read(reinterpret_cast<char*>(&ShowEvalBar), sizeof(bool))) ShowEvalBar = true;
                        if (!MyFile.read(reinterpret_cast<char*>(&FiveQueensMode), sizeof(bool))) FiveQueensMode = false;
                    }
                }
            } else {
                EngineType = 0;
                MinimaxDepth = 4;
                AnimationSpeed = 3.0f;
                AudioVolume = 50.0f;
                SoundEffects = true;
                AutoPromoteToQueen = false;
                EnableUndoRedo = true;
                ShowMoveHistory = true;
                ShowEvalBar = true;
                FiveQueensMode = false;
            }

            MyFile.close();
        }
        else {
            cerr << "Unable to open file for loading settings." << endl;
            DefaultInit(); // Load defaults if file cannot be opened
        }
    }

public:
    Settings() {
        if (FileExists("Settings.bin")) {
            cout << "Found Settings file" << endl;
            LoadSettingsFromFile();
        }
        else {
            cout << "Settings file not found, initializing defaults." << endl;
            DefaultInit();
            SaveSettingsToFile();
        }
    }

    void SaveSettingsToFile() {
        ofstream MyFile("Settings.bin", ios::binary);
        if (MyFile.is_open()) {
            // Write colors
            int numColors = Colors.size();
            MyFile.write(reinterpret_cast<char*>(&numColors), sizeof(int));
            for (auto& color : Colors) {
                MyFile.write(reinterpret_cast<char*>(&color), sizeof(Color));
            }

            // Write ModelLocations size and each string
            int numModels = ModelLocations.size();
            MyFile.write(reinterpret_cast<char*>(&numModels), sizeof(int));
            for (const auto& model : ModelLocations) {
                int size = model.size();
                MyFile.write(reinterpret_cast<char*>(&size), sizeof(int));
                MyFile.write(model.c_str(), size);
            }

            // Write Styles
            int numStyles = Styles.size();
            MyFile.write(reinterpret_cast<char*>(&numStyles), sizeof(int));
            for (const auto& style : Styles) {
                int size = style.size();
                MyFile.write(reinterpret_cast<char*>(&size), sizeof(int));
                MyFile.write(style.c_str(), size);
            }

            // Write current_style
            MyFile.write(reinterpret_cast<char*>(&current_style), sizeof(int));

            // Write StockfishPath
            int stockfishPathSize = StockfishPath.size();
            MyFile.write(reinterpret_cast<char*>(&stockfishPathSize), sizeof(int));
            MyFile.write(StockfishPath.c_str(), stockfishPathSize);

            // Write EngineType, MinimaxDepth, and AnimationSpeed
            MyFile.write(reinterpret_cast<char*>(&EngineType), sizeof(int));
            MyFile.write(reinterpret_cast<char*>(&MinimaxDepth), sizeof(int));
            MyFile.write(reinterpret_cast<char*>(&AnimationSpeed), sizeof(float));
            MyFile.write(reinterpret_cast<char*>(&AudioVolume), sizeof(float));
            MyFile.write(reinterpret_cast<char*>(&SoundEffects), sizeof(bool));
            MyFile.write(reinterpret_cast<char*>(&AutoPromoteToQueen), sizeof(bool));
            MyFile.write(reinterpret_cast<char*>(&EnableUndoRedo), sizeof(bool));
            MyFile.write(reinterpret_cast<char*>(&ShowMoveHistory), sizeof(bool));
            MyFile.write(reinterpret_cast<char*>(&ShowEvalBar), sizeof(bool));
            MyFile.write(reinterpret_cast<char*>(&FiveQueensMode), sizeof(bool));

            MyFile.close();
        }
        else {
            cerr << "Unable to open file for saving settings." << endl;
        }
    }

    ~Settings() {
        SaveSettingsToFile();
    }
};



#pragma once
#include "ChessPiece.h"


ChessPiece::ChessPiece(Vector3 pos,enum Type a,bool b)
{
	position = {pos.x,pos.y,pos.z};
	Name = a;
	colour = b;
	CustomLoader();
	box = GetModelBoundingBox(model);
	UpdateBoundingBox();
}

void ChessPiece::CustomLoader()
{
	switch (Name)
	{
	case King:
		if (colour) {
		model = LoadModel(Settings::ModelLocations[0].c_str());
		}
		else {
			model = LoadModel(Settings::ModelLocations[1].c_str());
		}
		break;
	case Queen:
		if (colour) {
			model = LoadModel(Settings::ModelLocations[2].c_str());
		}
		else {
			model = LoadModel(Settings::ModelLocations[3].c_str());
		}
		break;
	case Bishop:
		if (colour) {
			model = LoadModel(Settings::ModelLocations[4].c_str());
		}
		else {
			model = LoadModel(Settings::ModelLocations[5].c_str());
		}
		break;
	case Rook:
		if (colour) {
			model = LoadModel(Settings::ModelLocations[6].c_str());
		}
		else {
			model = LoadModel(Settings::ModelLocations[7].c_str());
		}
		break;
	case Knight:
		if (colour) {
			model = LoadModel(Settings::ModelLocations[8].c_str());
		}
		else {
			model = LoadModel(Settings::ModelLocations[9].c_str());
		}
		break;
	case Pawn:
		if (colour) {
			model = LoadModel(Settings::ModelLocations[10].c_str());
		}
		else {
			model = LoadModel(Settings::ModelLocations[11].c_str());
		}
		break;
	default:
		break;
	}
}

void ChessPiece::Draw()
{

	DrawModel(model, position, 1.0f, WHITE);
	//DrawBoundingBox(box, GREEN);
}

void ChessPiece::UpdateBoundingBox()
{
	box.min = Vector3Add(GetModelBoundingBox(model).min, position);
	box.max = Vector3Add(GetModelBoundingBox(model).max, position);
}

ChessPiece::~ChessPiece() {
	UnloadModel(model);
}

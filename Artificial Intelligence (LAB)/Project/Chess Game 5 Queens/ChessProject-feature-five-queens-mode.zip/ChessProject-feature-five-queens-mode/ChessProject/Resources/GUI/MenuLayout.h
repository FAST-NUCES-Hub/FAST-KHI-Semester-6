/*******************************************************************************************
*
*   MenuLayout v1.0.0 - Tool Description
*
*   MODULE USAGE:
*       #define GUI_MENULAYOUT_IMPLEMENTATION
*       #include "gui_MenuLayout.h"
*
*       INIT: GuiMenuLayoutState state = InitGuiMenuLayout();
*       DRAW: GuiMenuLayout(&state);
*
*   LICENSE: Propietary License
*
*   Copyright (c) 2022 Chess. All Rights Reserved.
*
*   Unauthorized copying of this file, via any medium is strictly prohibited
*   This project is proprietary and confidential unless the owner allows
*   usage in any other form by expresely written permission.
*
**********************************************************************************************/

#include "raylib.h"

// WARNING: raygui implementation is expected to be defined before including this header
#undef RAYGUI_IMPLEMENTATION
#include "raygui.h"

#include <string.h>     // Required for: strcpy()

#ifndef GUI_MENULAYOUT_H
#define GUI_MENULAYOUT_H

typedef struct {
    // Define anchors
    Vector2 MainAnchor;            // ANCHOR ID:1
    
    // Define controls variables
    bool WindowBox000Active;            // WindowBox: WindowBox000
    int ToggleGroup004Active;            // ToggleGroup: ToggleGroup004

    // Define rectangles
    Rectangle layoutRecs[6];

    // Custom state variables (depend on development software)
    // NOTE: This variables should be added manually if required

} GuiMenuLayoutState;

#ifdef __cplusplus
extern "C" {            // Prevents name mangling of functions
#endif

//----------------------------------------------------------------------------------
// Defines and Macros
//----------------------------------------------------------------------------------
//...

//----------------------------------------------------------------------------------
// Types and Structures Definition
//----------------------------------------------------------------------------------
// ...

//----------------------------------------------------------------------------------
// Module Functions Declaration
//----------------------------------------------------------------------------------
GuiMenuLayoutState InitGuiMenuLayout(void);
void GuiMenuLayout(GuiMenuLayoutState *state);
static void PlayGameButton();                // Button: PlayGameButton logic
static void SettingsButton();                // Button: SettingsButton logic
static void ExitGameButton();                // Button: ExitGameButton logic

#ifdef __cplusplus
}
#endif

#endif // GUI_MENULAYOUT_H

/***********************************************************************************
*
*   GUI_MENULAYOUT IMPLEMENTATION
*
************************************************************************************/
#if defined(GUI_MENULAYOUT_IMPLEMENTATION)

#include "raygui.h"

//----------------------------------------------------------------------------------
// Global Variables Definition
//----------------------------------------------------------------------------------
//...

//----------------------------------------------------------------------------------
// Internal Module Functions Definition
//----------------------------------------------------------------------------------
//...

//----------------------------------------------------------------------------------
// Module Functions Definition
//----------------------------------------------------------------------------------
GuiMenuLayoutState InitGuiMenuLayout(void)
{
    GuiMenuLayoutState state = { 0 };

    // Init anchors - Centered on screen (menu window is 696x528)
    state.MainAnchor = Vector2{ (float)(GetScreenWidth() - 696) / 2, (float)(GetScreenHeight() - 528) / 2 };            // ANCHOR ID:1
    
    // Initilize controls variables
    state.WindowBox000Active = true;            // WindowBox: WindowBox000
    state.ToggleGroup004Active = 0;            // ToggleGroup: ToggleGroup004

    // Init controls rectangles
    state.layoutRecs[0] = Rectangle{ state.MainAnchor.x + 0, state.MainAnchor.y + 0, 696, 528 };// WindowBox: WindowBox000
    state.layoutRecs[1] = Rectangle{ state.MainAnchor.x + 258, state.MainAnchor.y + 192, 180, 64 };// Button: PlayGameButton
    state.layoutRecs[2] = Rectangle{ state.MainAnchor.x + 258, state.MainAnchor.y + 344, 180, 56 };// Button: SettingsButton
    state.layoutRecs[3] = Rectangle{ state.MainAnchor.x + 258, state.MainAnchor.y + 424, 180, 56 };// Button: ExitGameButton
    state.layoutRecs[4] = Rectangle{ state.MainAnchor.x + 258, state.MainAnchor.y + 272, 180, 51 };// ToggleGroup: ToggleGroup004
    state.layoutRecs[5] = Rectangle{ state.MainAnchor.x + 190, state.MainAnchor.y + 272, 60, 52 };// Label: Label005

    // Custom variables initialization

    return state;
}
// Button: PlayGameButton logic
static void PlayGameButton(GameState& type)
{
    type = GameScreen;
}
// Button: SettingsButton logic
static void SettingsButton(GameState& type)
{
    type = SettingsScreen;
}
// Button: ExitGameButton logic
static void ExitGameButton(GameState& type)
{
    CloseWindow();
    exit(0);
}


void GuiMenuLayout(GuiMenuLayoutState *state, GameState& type)
{
    // Const text
    const char *WindowBox000Text = "Chess Game";    // WINDOWBOX: WindowBox000
    const char *PlayGameButtonText = "Play Game";    // BUTTON: PlayGameButton
    const char *SettingsButtonText = "Settings";    // BUTTON: SettingsButton
    const char *ExitGameButtonText = "Exit Game";    // BUTTON: ExitGameButton
    const char *ToggleGroup004Text = "VS Player;VS AI";    // TOGGLEGROUP: ToggleGroup004
    const char *Label005Text = "Mode:";    // LABEL: Label005
    
    // Draw controls
    if (state->WindowBox000Active)
    {
        state->WindowBox000Active = !GuiWindowBox(state->layoutRecs[0], WindowBox000Text);
        if (GuiButton(state->layoutRecs[1], PlayGameButtonText)) PlayGameButton(type); 
        if (GuiButton(state->layoutRecs[2], SettingsButtonText)) SettingsButton(type); 
        if (GuiButton(state->layoutRecs[3], ExitGameButtonText)) ExitGameButton(type); 
        GuiToggleGroup(state->layoutRecs[4], ToggleGroup004Text, &state->ToggleGroup004Active);
        GuiLabel(state->layoutRecs[5], Label005Text);
    }
}

#endif // GUI_MENULAYOUT_IMPLEMENTATION

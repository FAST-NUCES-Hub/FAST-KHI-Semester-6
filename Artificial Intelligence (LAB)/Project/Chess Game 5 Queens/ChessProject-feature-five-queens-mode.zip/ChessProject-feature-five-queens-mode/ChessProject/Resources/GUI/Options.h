/*******************************************************************************************
*
*   Options v1.0.0 - This is the layout for Options Screen
*
*   MODULE USAGE:
*       #define GUI_OPTIONS_IMPLEMENTATION
*       #include "gui_Options.h"
*
*       INIT: GuiOptionsState state = InitGuiOptions();
*       DRAW: GuiOptions(&state);
*
*   LICENSE: Propietary License
*
*   Copyright (c) 2022 Chess. All Rights Reserved.
*
*   Unauthorized copying of this file, via any medium is strictly prohibited
*   This project is proprietary and confidential unless the owner allows
*   usage in any other form by expresely written permission.
*
**********************************************************************************************/

#include "raylib.h"

// WARNING: raygui implementation is expected to be defined before including this header
#undef RAYGUI_IMPLEMENTATION
#include "raygui.h"

#include <string.h>     // Required for: strcpy()

#ifndef GUI_OPTIONS_H
#define GUI_OPTIONS_H

typedef struct {
    // Define anchors
    Vector2 anchor01;            // ANCHOR ID:1
    
    // Define controls variables
    bool EntireWindowBoxActive;            // WindowBox: EntireWindowBox
    float AudioSliderBarValue;            // SliderBar: AudioSliderBar
    bool SoundEffectCheckBoxChecked;            // CheckBoxEx: SoundEffectCheckBox
    bool AutoQueenCheckBoxChecked;      // CheckBoxEx: AutoQueenCheckBox
    bool EnableUndoRedoCheckBoxChecked; // CheckBoxEx: EnableUndoRedo
    bool ShowMoveHistoryCheckBoxChecked;// CheckBoxEx: ShowMoveHistory
    bool ShowEvalBarCheckBoxChecked;    // CheckBoxEx: ShowEvalBar
    bool FiveQueensModeCheckBoxChecked; // CheckBoxEx: FiveQueensMode
    int ListViewThemesScrollIndex;
    int ListViewThemesActive;            // ListView: ListViewThemes
    Color ColorPickerValue;            // ColorPicker: ColorPicker
    bool ColourDropDownEditMode;
    int ColourDropDownActive;            // DropdownBox: ColourDropDown
    int ListViewModelsScrollIndex;
    int ListViewModelsActive;            // ListView: ListViewModels
    bool EngineDropDownEditMode;
    int EngineDropDownActive;            // DropdownBox: Engine selection
    float MinimaxDepthValue;             // Slider: Minimax depth
    float AnimationSpeedValue;           // Slider: Animation speed
    int lastColourDropDownActive;        // State for color picker tracking

    // Define rectangles
    Rectangle layoutRecs[29];

    // Custom state variables (depend on development software)
    // NOTE: This variables should be added manually if required

} GuiOptionsState;

#ifdef __cplusplus
extern "C" {            // Prevents name mangling of functions
#endif

//----------------------------------------------------------------------------------
// Defines and Macros
//----------------------------------------------------------------------------------
//...

//----------------------------------------------------------------------------------
// Types and Structures Definition
//----------------------------------------------------------------------------------
// ...

//----------------------------------------------------------------------------------
// Module Functions Declaration
//----------------------------------------------------------------------------------
GuiOptionsState InitGuiOptions(void);
void GuiOptions(GuiOptionsState *state);
static void FileButton();                // Button: FileButton logic
static void SaveButton();                // Button: SaveButton logic
static void ColorUpdate();
#ifdef __cplusplus
}
#endif

#endif // GUI_OPTIONS_H

/***********************************************************************************
*
*   GUI_OPTIONS IMPLEMENTATION
*
************************************************************************************/
#if defined(GUI_OPTIONS_IMPLEMENTATION)

#include "raygui.h"
#include "gui_window_file_dialog.h"

//----------------------------------------------------------------------------------
// Global Variables Definition
//----------------------------------------------------------------------------------
//...

//----------------------------------------------------------------------------------
// Internal Module Functions Definition
//----------------------------------------------------------------------------------
//...

//----------------------------------------------------------------------------------
// Module Functions Definition
//----------------------------------------------------------------------------------
GuiOptionsState InitGuiOptions(void)
{
    GuiOptionsState state = { 0 };

    // Init anchors - Centered on screen (settings window is 552x648)
    state.anchor01 = Vector2{ (float)(GetScreenWidth() - 552) / 2, (float)(GetScreenHeight() - 648) / 2 };            // ANCHOR ID:1
    
    // Initilize controls variables
    state.EntireWindowBoxActive = true;            // WindowBox: EntireWindowBox
    state.AudioSliderBarValue = Settings::AudioVolume;            // SliderBar: AudioSliderBar
    state.SoundEffectCheckBoxChecked = Settings::SoundEffects;            // CheckBoxEx: SoundEffectCheckBox
    state.AutoQueenCheckBoxChecked = Settings::AutoPromoteToQueen;
    state.EnableUndoRedoCheckBoxChecked = Settings::EnableUndoRedo;
    state.ShowMoveHistoryCheckBoxChecked = Settings::ShowMoveHistory;
    state.ShowEvalBarCheckBoxChecked = Settings::ShowEvalBar;
    state.FiveQueensModeCheckBoxChecked = Settings::FiveQueensMode;
    state.ListViewThemesScrollIndex = 0;
    state.ListViewThemesActive = 0;            // ListView: ListViewThemes
    state.ColorPickerValue = Settings::Colors.empty() ? RED : Settings::Colors[0];            // ColorPicker: ColorPicker
    state.ColourDropDownEditMode = false;
    state.ColourDropDownActive = 0;            // DropdownBox: ColourDropDown
    state.lastColourDropDownActive = 0;
    state.ListViewModelsScrollIndex = 0;
    state.ListViewModelsActive = 0;            // ListView: ListViewModels
    state.EngineDropDownEditMode = false;
    state.EngineDropDownActive = Settings::EngineType;
    state.MinimaxDepthValue = (float)Settings::MinimaxDepth;
    state.AnimationSpeedValue = Settings::AnimationSpeed;

    // Init controls rectangles
    state.layoutRecs[0] = Rectangle{ state.anchor01.x + 0, state.anchor01.y + 0, 552, 648 };// WindowBox: EntireWindowBox
    state.layoutRecs[1] = Rectangle{ state.anchor01.x + 40, state.anchor01.y + 104, 136, 24 };// SliderBar: AudioSliderBar
    state.layoutRecs[2] = Rectangle{ state.anchor01.x + 16, state.anchor01.y + 72, 176, 240 };// GroupBox: GroupBoxGameSettings
    state.layoutRecs[3] = Rectangle{ state.anchor01.x + 40, state.anchor01.y + 140, 24, 24 };// CheckBoxEx: SoundEffectCheckBox
    state.layoutRecs[20] = Rectangle{ state.anchor01.x + 40, state.anchor01.y + 170, 24, 24 };// CheckBoxEx: AutoQueenCheckBox
    state.layoutRecs[21] = Rectangle{ state.anchor01.x + 40, state.anchor01.y + 200, 24, 24 };// CheckBoxEx: EnableUndoRedoCheckBox
    state.layoutRecs[22] = Rectangle{ state.anchor01.x + 40, state.anchor01.y + 230, 24, 24 };// CheckBoxEx: ShowMoveHistoryCheckBox
    state.layoutRecs[23] = Rectangle{ state.anchor01.x + 40, state.anchor01.y + 260, 24, 24 };// CheckBoxEx: ShowEvalBarCheckBox
    state.layoutRecs[24] = Rectangle{ state.anchor01.x + 40, state.anchor01.y + 290, 24, 24 };// CheckBoxEx: FiveQueensMode
    state.layoutRecs[4] = Rectangle{ state.anchor01.x + 16, state.anchor01.y + 318, 176, 162 };// GroupBox: GroupBoxTheme
    state.layoutRecs[5] = Rectangle{ state.anchor01.x + 32, state.anchor01.y + 342, 144, 122 };// ListView: ListViewThemes
    state.layoutRecs[6] = Rectangle{ state.anchor01.x + 224, state.anchor01.y + 72, 304, 160 };// GroupBox: GroupBoxColour
    state.layoutRecs[7] = Rectangle{ state.anchor01.x + 392, state.anchor01.y + 96, 96, 96 };// ColorPicker: ColorPicker
    state.layoutRecs[8] = Rectangle{ state.anchor01.x + 248, state.anchor01.y + 96, 120, 24 };// DropdownBox: ColourDropDown
    state.layoutRecs[9] = Rectangle{ state.anchor01.x + 224, state.anchor01.y + 288, 304, 192 };// GroupBox: GroupBox009
    state.layoutRecs[10] = Rectangle{ state.anchor01.x + 240, state.anchor01.y + 312, 200, 152 };// ListView: ListViewModels
    state.layoutRecs[11] = Rectangle{ state.anchor01.x + 448, state.anchor01.y + 312, 64, 56 };// Button: FileButton
    state.layoutRecs[12] = Rectangle{ state.anchor01.x + 392, state.anchor01.y + 600, 136, 24 };// Button: SaveButton (moved down)
    // Engine Settings
    state.layoutRecs[13] = Rectangle{ state.anchor01.x + 16, state.anchor01.y + 496, 512, 88 };// GroupBox: Engine Settings
    state.layoutRecs[14] = Rectangle{ state.anchor01.x + 104, state.anchor01.y + 520, 120, 24 };// DropdownBox: Engine
    state.layoutRecs[15] = Rectangle{ state.anchor01.x + 32, state.anchor01.y + 520, 64, 24 };// Label: "Engine:"
    state.layoutRecs[16] = Rectangle{ state.anchor01.x + 312, state.anchor01.y + 520, 120, 24 };// Slider: Depth
    state.layoutRecs[17] = Rectangle{ state.anchor01.x + 230, state.anchor01.y + 520, 72, 24 };// Label: "Depth:"
    state.layoutRecs[18] = Rectangle{ state.anchor01.x + 312, state.anchor01.y + 550, 120, 24 };// Slider: Anim Speed
    state.layoutRecs[19] = Rectangle{ state.anchor01.x + 230, state.anchor01.y + 550, 72, 24 };// Label: "Anim Speed:"

    // Custom variables initialization

    return state;
}
// Button: FileButton logic
void FileButton(GameState& Gamestate)
{
    Gamestate = FileSelectionScreen;
}
// Button: SaveButton logic
static void SaveButton(GameState& state,Settings& options)
{
    if (options.current_style != -1) {
        if (options.current_style == 0) {
            GuiLoadStyleDefault();
        } else GuiLoadStyle(options.Styles[options.current_style].c_str());
    }

    options.SaveSettingsToFile();
    state = MenuScreen;
    
}
static void ColorUpdate(GuiOptionsState* state, Settings& options) {
    options.Colors[state->ColourDropDownActive] = Color{state->ColorPickerValue.r,state->ColorPickerValue.g,state->ColorPickerValue.b,255};
}

void GuiOptions(GuiOptionsState *state,Settings& options,GameState& Gamestate)
{
    // Const text
    const char *EntireWindowBoxText = "SETTINGS MENU";    // WINDOWBOX: EntireWindowBox
    const char *AudioSliderBarText = "#122#";    // SLIDERBAR: AudioSliderBar
    const char *GroupBoxAudioText = "Game Settings";    // GROUPBOX: GroupBoxAudio
    const char *SoundEffectCheckBoxText = "Sound Effects";    // CHECKBOXEX: SoundEffectCheckBox
    const char *AutoQueenCheckBoxText = "Auto Promote to Queen"; // CHECKBOXEX: AutoQueenCheckBox
    const char *EnableUndoRedoText = "Enable Undo/Redo"; // CHECKBOXEX
    const char *ShowMoveHistoryText = "Show Move History"; // CHECKBOXEX
    const char *ShowEvalBarText = "Show Eval Bar"; // CHECKBOXEX
    const char *FiveQueensModeText = "Five Queens Mode"; // CHECKBOXEX
    const char *GroupBoxThemeText = "Theme Settings";    // GROUPBOX: GroupBoxTheme
    const char *ListViewThemesText = "Default;Ashes;Bluish;Candy;Cherry;Cyber;Dark;Enefete(WIP);Jungle;Lavanda;Sunny(WIP);Terminal";    // LISTVIEW: ListViewThemes
    const char *GroupBoxColourText = "Colours Setting";    // GROUPBOX: GroupBoxColour
    const char *ColourDropDownText = "HighlightColor;SelectionColour;LegalMoveColor;FinalSelectionColor;White Spot;Black Spot";    // DROPDOWNBOX: ColourDropDown
    const char *GroupBox009Text = "Models";    // GROUPBOX: GroupBox009
    const char *ListViewModelsText = "White King;Black King;White Queen;Black Queen;White Bishop;Black Bishop;White Rook;Black Rook;White Knight;Black Knight;White Pawn;Black Pawn";    // LISTVIEW: ListViewModels
    const char *FileButtonText = "#001#";    // BUTTON: FileButton
    const char *SaveButtonText = "SAVE";    // BUTTON: SaveButton
    const char* ColorPickerText = "Pick Colour";
    const char *EngineDropDownText = "Stockfish;Minimax";
    const char *GroupBoxEngineText = "Engine & Animation Settings";
    const char *EngineLabelText = "Engine:";
    const char *DepthLabelText = "Depth:";
    const char *AnimSpeedLabelText = "Anim Speed:";

    // Draw controls
    if (state->ColourDropDownEditMode || state->EngineDropDownEditMode) GuiLock();

    if (state->EntireWindowBoxActive)
    {
        state->EntireWindowBoxActive = !GuiWindowBox(state->layoutRecs[0], EntireWindowBoxText);
        GuiSliderBar(state->layoutRecs[1], AudioSliderBarText, NULL, &state->AudioSliderBarValue, 0, 100);
        GuiGroupBox(state->layoutRecs[2], GroupBoxAudioText);
        GuiCheckBox(state->layoutRecs[3], SoundEffectCheckBoxText, &state->SoundEffectCheckBoxChecked);
        GuiCheckBox(state->layoutRecs[20], AutoQueenCheckBoxText, &state->AutoQueenCheckBoxChecked);
        GuiCheckBox(state->layoutRecs[21], EnableUndoRedoText, &state->EnableUndoRedoCheckBoxChecked);
        GuiCheckBox(state->layoutRecs[22], ShowMoveHistoryText, &state->ShowMoveHistoryCheckBoxChecked);
        GuiCheckBox(state->layoutRecs[23], ShowEvalBarText, &state->ShowEvalBarCheckBoxChecked);
        GuiCheckBox(state->layoutRecs[24], FiveQueensModeText, &state->FiveQueensModeCheckBoxChecked);
        GuiGroupBox(state->layoutRecs[4], GroupBoxThemeText);
        GuiListView(state->layoutRecs[5], ListViewThemesText, &state->ListViewThemesScrollIndex, &state->ListViewThemesActive);
        GuiGroupBox(state->layoutRecs[6], GroupBoxColourText);
        GuiColorPicker(state->layoutRecs[7], ColorPickerText, &state->ColorPickerValue);
        GuiGroupBox(state->layoutRecs[9], GroupBox009Text);
        GuiListView(state->layoutRecs[10], ListViewModelsText, &state->ListViewModelsScrollIndex, &state->ListViewModelsActive);
        if (GuiButton(state->layoutRecs[11], FileButtonText)) FileButton(Gamestate);
        if (GuiButton(state->layoutRecs[12], SaveButtonText)) { 
            options.current_style = state->ListViewThemesActive;
            options.EngineType = state->EngineDropDownActive;
            options.MinimaxDepth = (int)state->MinimaxDepthValue;
            if (options.MinimaxDepth < 1) options.MinimaxDepth = 1;
            if (options.MinimaxDepth > 6) options.MinimaxDepth = 6;
            options.AnimationSpeed = state->AnimationSpeedValue;
            if (options.AnimationSpeed < 0.5f) options.AnimationSpeed = 0.5f;
            if (options.AnimationSpeed > 10.0f) options.AnimationSpeed = 10.0f;
            options.AudioVolume = state->AudioSliderBarValue;
            options.SoundEffects = state->SoundEffectCheckBoxChecked;
            options.AutoPromoteToQueen = state->AutoQueenCheckBoxChecked;
            options.EnableUndoRedo = state->EnableUndoRedoCheckBoxChecked;
            options.ShowMoveHistory = state->ShowMoveHistoryCheckBoxChecked;
            options.ShowEvalBar = state->ShowEvalBarCheckBoxChecked;
            options.FiveQueensMode = state->FiveQueensModeCheckBoxChecked;
            SaveButton(Gamestate, options);
        }

        // Engine Settings group
        GuiGroupBox(state->layoutRecs[13], GroupBoxEngineText);
        GuiLabel(state->layoutRecs[15], EngineLabelText);
        GuiLabel(state->layoutRecs[17], DepthLabelText);
        GuiLabel(state->layoutRecs[19], AnimSpeedLabelText);

        // Depth slider - only enabled when Minimax is selected
        if (state->EngineDropDownActive == 0) GuiDisable();
        char depthText[8];
        sprintf(depthText, "%d", (int)state->MinimaxDepthValue);
        GuiSlider(state->layoutRecs[16], NULL, depthText, &state->MinimaxDepthValue, 1, 6);
        if (state->EngineDropDownActive == 0) GuiEnable();

        // Animation speed slider
        char animSpeedText[16];
        sprintf(animSpeedText, "%.1fx", state->AnimationSpeedValue);
        GuiSlider(state->layoutRecs[18], NULL, animSpeedText, &state->AnimationSpeedValue, 0.5f, 10.0f);

        // Dropdowns drawn last (on top)
        if (GuiDropdownBox(state->layoutRecs[8], ColourDropDownText, &state->ColourDropDownActive, state->ColourDropDownEditMode)) state->ColourDropDownEditMode = !state->ColourDropDownEditMode;
        if (GuiDropdownBox(state->layoutRecs[14], EngineDropDownText, &state->EngineDropDownActive, state->EngineDropDownEditMode)) state->EngineDropDownEditMode = !state->EngineDropDownEditMode;
        
        if (state->ColourDropDownActive != state->lastColourDropDownActive) {
            state->ColorPickerValue = options.Colors[state->ColourDropDownActive];
            state->lastColourDropDownActive = state->ColourDropDownActive;
        } else {
            ColorUpdate(state,options);
        }
    }
    GuiUnlock();
}

#endif // GUI_OPTIONS_IMPLEMENTATION

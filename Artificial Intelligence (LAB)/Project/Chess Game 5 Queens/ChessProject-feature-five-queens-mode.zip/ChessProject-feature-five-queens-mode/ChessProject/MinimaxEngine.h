#pragma once
#include "IChessEngine.h"
#include "Spot.h"
#include <vector>
#include <string>
#include <climits>

using namespace std;

// Piece constants (positive = white, negative = black)
const int EMPTY_SQUARE = 0;
const int W_PAWN = 1;
const int W_KNIGHT = 2;
const int W_BISHOP = 3;
const int W_ROOK = 4;
const int W_QUEEN = 5;
const int W_KING = 6;
const int B_PAWN = -1;
const int B_KNIGHT = -2;
const int B_BISHOP = -3;
const int B_ROOK = -4;
const int B_QUEEN = -5;
const int B_KING = -6;

// Undo info for unmaking moves
struct MoveUndo {
	int fromRow, fromCol, toRow, toCol;
	int movedPiece;
	int capturedPiece;
	bool castlingRights[4]; // KQkq before the move
	int enPassantCol;
	bool wasEnPassant;
	bool wasCastling;
	int promotedTo; // 0 if no promotion
};

class MinimaxEngine : public IChessEngine {
private:
	int board[8][8]; // internal board representation
	bool whiteToMove;
	bool castlingRights[4]; // K, Q, k, q
	int enPassantCol; // -1 if none, otherwise column of pawn that just double-pushed
	int enPassantRow; // target row for en passant capture
	vector<string> moveHistory;

	// Piece values
	static const int PAWN_VALUE = 100;
	static const int KNIGHT_VALUE = 320;
	static const int BISHOP_VALUE = 330;
	static const int ROOK_VALUE = 500;
	static const int QUEEN_VALUE = 900;
	static const int KING_VALUE = 20000;

	// Core engine methods
	int evaluate();
	int minimax(int depth, int alpha, int beta, bool maximizing);
	vector<string> generateAllPseudoLegalMoves(bool forWhite);
	vector<string> generateAllLegalMoves(bool forWhite);
	bool isSquareAttacked(int row, int col, bool byWhite);
	bool isInCheck(bool whiteKing);
	void applyMove(const string& move, MoveUndo& undo);
	void undoMove(const MoveUndo& undo);
	int getPieceValue(int piece);
	int getPieceSquareBonus(int piece, int row, int col);
	bool isWhitePiece(int piece);
	bool isBlackPiece(int piece);
	void initStartPosition();
	char pieceToChar(int piece);
	int charToPiece(char c);
	string squareToAlgebraic(int row, int col);
	void algebraicToSquare(const string& s, int& row, int& col);

public:
	MinimaxEngine();

	// IChessEngine interface
	vector<string> list_all_legal_moves() override;
	vector<string> list_legal_moves(string position) override;
	void update_moves(string move) override;
	string FenExtracter() override;
	vector<vector<char>> BoardMaker() override;
	int WinChecker(Spot board[8][8]) override;
	string GetBestMove(int depth) override;
	void set_moves(const vector<string>& current_moves) override;
	float GetEvaluation() override;
	void set_starting_fen(const string& fen) override;

private:
	void loadFEN(const string& fen);
	string starting_fen;
};

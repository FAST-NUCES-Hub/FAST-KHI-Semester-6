#include "Spot.h"

Spot::Spot(Vector3 pos, ChessPiece* p, bool color)
{
	position = pos;
	piece = p;
	colour = color;
	Vector3 cubeSize = { 1.0f,1.0f,1.0f };
	spotbox.min = Vector3{ position.x - cubeSize.x / 2, position.y - cubeSize.y / 2, position.z - cubeSize.z / 2 };
	spotbox.max = Vector3{ position.x + cubeSize.x / 2, position.y + cubeSize.y / 2, position.z + cubeSize.z / 2 };
}

Spot::Spot() {

}

void Spot::Draw()
{
	DrawCube(position, 1.0f, 1.0f, 1.0f, colour ? Colors[4] : Colors[5]);
	//DrawBoundingBox(spotbox, BLUE);
	
}
void Spot::DrawPiece()
{
	piece->Draw();
}

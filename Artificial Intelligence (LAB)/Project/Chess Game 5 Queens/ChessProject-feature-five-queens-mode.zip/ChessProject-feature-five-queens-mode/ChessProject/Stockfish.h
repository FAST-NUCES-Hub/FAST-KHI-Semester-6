#pragma once
#include <subprocess.h>
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include "Spot.h"
#include "Settings.h"
#include "IChessEngine.h"

using namespace std;

class Stockfish : public IChessEngine
{
	const char* command[2] = { nullptr, NULL };
	struct subprocess_s stockfish;
	FILE* stock_in;
	FILE* stock_out;
	char output[1000];
	vector <string> moves;
public:
	Stockfish();
	void input_stockfish(string query);
	string read_stockfish();
	vector <string> list_all_legal_moves() override;
	vector <string> list_legal_moves(string postion) override;
	~Stockfish();
	void update_moves(string move) override;
	string FenExtracter() override;
	vector<vector <char>> BoardMaker() override;
	int WinChecker(Spot board[8][8]) override;
	string GetBestMove(int depth) override;
	void set_moves(const vector<string>& current_moves) override;
	float GetEvaluation() override;
	void set_starting_fen(const string& fen) override;
private:
	string starting_fen;
};

#pragma once
#include <raylib.h>
#include <vector>
#include <string>
using namespace std;

enum GameState { LoadingScreen, MenuScreen, GameScreen, SettingsScreen, WinningScreen, FileSelectionScreen, PauseScreen, PromotionScreen };
class MainMenu
{
	vector <Rectangle> Buttons;
	vector <string> Labels;
	void DrawButtons();
	void DrawLabels(int offset, Color colour, int fontsize);
	int CollisionChecker(Color HighlightColour, Color TextColour, int offset, int fontsize);
	void Action(int query, GameState& para);
	void DrawButton(Rectangle button, Color colour);
	void DrawLabel(string label, Vector2 pos, Color colour, int offset, int fontsize);

public:
	MainMenu(vector <Rectangle> button,vector <string> Labels);
	void Update(GameState& para);
};


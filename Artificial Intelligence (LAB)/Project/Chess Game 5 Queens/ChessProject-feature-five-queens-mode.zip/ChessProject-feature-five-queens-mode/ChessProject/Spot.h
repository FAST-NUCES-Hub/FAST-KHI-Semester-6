#pragma once
#include "ChessPiece.h"
#include "Settings.h"
class Spot :public Settings
{
public:
	Vector3 position;
	ChessPiece* piece;
	bool colour;
	BoundingBox spotbox;

	Spot();
	Spot(Vector3 pos ,ChessPiece* p,bool color);
	void Draw();

	void DrawPiece();



};


#include "Stockfish.h"


Stockfish::Stockfish() {
	// Set the command path from Settings
	command[0] = Settings::StockfishPath.c_str();
	
	int result = subprocess_create(command, subprocess_option_enable_async , &stockfish);
	if (result != 0) {
		cout << "Error Occured!" << endl << "Most Likely Your We Cannot Find the Stockfish.exe on your Computer";
	}
	else {
		stock_in = subprocess_stdin(&stockfish);
		stock_out = subprocess_stdout(&stockfish);

		//cout << read_stockfish();
	}
}
void Stockfish::input_stockfish(string query) {
	fputs(query.c_str(), stock_in);
	fflush(stock_in);
	//cout << query << endl;
}

string Stockfish::read_stockfish() {
	//subprocess_read_stdout(&stockfish, output, 1000);
	fgets(output, sizeof(output), stock_out);
	//cout << output << endl;
	return string(output);
}

vector<string> Stockfish::list_all_legal_moves()
{
	vector <string> legalmoves;
	input_stockfish("go perft 1\n");
	string out;
	while (true) {
		out = read_stockfish();
		if (out.substr(0, 5) == "Nodes") {
			break;
		}
		else if (out.find(": ") != string::npos) {
			size_t colonPos = out.find(": ");
			legalmoves.push_back(out.substr(0, colonPos));
		}
	}
	return legalmoves;
}

vector<string> Stockfish::list_legal_moves(string postion)
{
	vector <string> alllegal = list_all_legal_moves();
	vector <string> legal;
	for (auto a : alllegal) {
		if (a[0] == postion[0] && a[1] == postion[1]) {
			legal.push_back(a);
		}
	}
	return legal;
}

Stockfish::~Stockfish()
{
	subprocess_destroy(&stockfish);
}

void Stockfish::update_moves(string move)
{
	moves.push_back(move);
	string line;
	for (auto str : moves) line += str + " ";
	if (starting_fen.empty()) {
		input_stockfish("position startpos moves " + line + "\r\n");
	} else {
		input_stockfish("position fen " + starting_fen + " moves " + line + "\r\n");
	}
}

string Stockfish::FenExtracter()
{
	input_stockfish("d\n");
	string Fen;
	while (true)
	{
		Fen = read_stockfish();
		if (Fen.substr(0, 5) == "Fen: ") {
			Fen = Fen.substr(5, Fen.size());
			break;
		}
	}
	return Fen;
}

vector<vector <char>> Stockfish::BoardMaker()
{

	vector<vector <char>> board(8, vector <char>(8, 'E'));
	//string fen = "rnbqkbnr/pp1p1ppp/8/2p1p3/2P1P3/8/PP1P1PPP/RNBQKBNR";
	string fen = FenExtracter();
	for (int i = 0; i < fen.size(); i++) {
		if (fen[i] == ' ') {
			fen = fen.substr(0, i);
			break;
		}
	}

	//reverse(fen.begin(), fen.end());

	int row = 0;
	int col = 0;

	for (size_t i = 0; i < fen.size(); ++i) {
		char current = fen[i];

		if (current == ' ') {
			break; // Stop parsing if we encounter a space (end of position part of FEN)
		}

		if (current == '/') {
			// Move to the next row
			row++;
			col = 0;
		}
		else if (isdigit(current)) {
			// Skip 'current' number of empty squares
			col += (current - '0');
		}
		else {
			// Place piece on the board
			board[row][col] = current;
			col++;
		}
	}
	
	// Print the board for debugging
	for (int i = 0; i < 8; i++) {
		for (int j = 0; j < 8; j++) {
			cout << board[i][j] << " ";
		}
		cout << endl;
	}
	return board;
	
}

int Stockfish::WinChecker(Spot board[8][8])
{
	input_stockfish("go movetime 1\n");
	string res;
	while (true) {
		res = read_stockfish();
		if (res.substr(0, 9) == "bestmove ") break;
	}
	res = res.substr(9, res.size());
	if (res == "(none)\r\n") {
		input_stockfish("d\n");
		string res2;
		while (true)
		{
			res2 = read_stockfish();
			if (res2.substr(0, 10) == "Checkers: ") {
				res2 = res2.substr(10, res2.size());
				break;
			}
		}
		if (res2 == "\r\n") {
			//cout << "stalemate" << endl;
			return 3;
		}
		else {
			if (!board[res2[1] - '1'][res[0] - 'a'].colour) {
				//cout << "White Won\n";
				return 1;
			}
			else {
				//cout << "Black Won\n";
				return 2;
			}
		}
	}
	else {
		//cout << "No one Won\n";
		return 0;
	}
}

string Stockfish::GetBestMove(int depth) {
	input_stockfish("go depth " + to_string(depth) + "\n");
	string res;
	while (true) {
		res = read_stockfish();
		if (res.substr(0, 9) == "bestmove ") break;
	}
	res = res.substr(9, res.size());
	// Extract just the move (before any space/ponder)
	string bestMove;
	for (char c : res) {
		if (c == ' ' || c == '\r' || c == '\n') break;
		bestMove += c;
	}
	return bestMove;
}

void Stockfish::set_moves(const vector<string>& current_moves) {
	moves = current_moves;
	string line;
	for (auto str : moves) line += str + " ";
	if (starting_fen.empty()) {
		input_stockfish("position startpos moves " + line + "\r\n");
	} else {
		input_stockfish("position fen " + starting_fen + " moves " + line + "\r\n");
	}
}

void Stockfish::set_starting_fen(const string& fen) {
	starting_fen = fen;
	if (fen.empty()) {
		input_stockfish("position startpos\r\n");
	} else {
		input_stockfish("position fen " + fen + "\r\n");
	}
}

float Stockfish::GetEvaluation() {
	input_stockfish("go depth 1\n");
	string res;
	float score = 0.0f;
	while (true) {
		res = read_stockfish();
		if (res.find("score cp ") != string::npos) {
			size_t pos = res.find("score cp ");
			size_t end = res.find(" ", pos + 9);
			string scoreStr = res.substr(pos + 9, end - (pos + 9));
			try {
				score = stof(scoreStr) / 100.0f; // centipawns to pawns
			} catch (...) {}
		} else if (res.find("score mate ") != string::npos) {
			size_t pos = res.find("score mate ");
			size_t end = res.find(" ", pos + 11);
			string scoreStr = res.substr(pos + 11, end - (pos + 11));
			try {
				float mateIn = stof(scoreStr);
				score = mateIn > 0 ? 100.0f : -100.0f;
			} catch (...) {}
		}
		if (res.substr(0, 9) == "bestmove ") break;
	}
	if (moves.size() % 2 != 0) {
		score = -score;
	}
	return score;
}

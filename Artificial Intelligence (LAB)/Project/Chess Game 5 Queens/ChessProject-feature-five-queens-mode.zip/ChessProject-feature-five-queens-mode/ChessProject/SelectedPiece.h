#pragma once
#include "Spot.h"
class SelectedPiece
{
public:
	int row;
	int col;
	bool selected;
	Spot* current;
	SelectedPiece();
	void SetSelectedPiece(int i , int j,Spot* spot);
	void ToggleSelected();
	bool IsSelected();
	bool Validate(int i ,int j);
	void Working();
	void Unselect();
};


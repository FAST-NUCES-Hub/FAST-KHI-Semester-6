#include "SelectedPiece.h"

SelectedPiece::SelectedPiece()
{
    row = -1;
    col = -1;
    selected = false;
    current = nullptr;
}

void SelectedPiece::SetSelectedPiece(int i,int j,Spot* spot)
{
        this->row = i;
        this->col = j;
        selected = true;
        current = spot;

}

void SelectedPiece::ToggleSelected()
{
    selected = !selected;
}

bool SelectedPiece::IsSelected()
{
    if (selected) {
        return true;
    }
    else {
        return false;
    }
}

bool SelectedPiece::Validate(int i, int j)
{
    if (row == i && col == j ){
        return true;
    }
    return false;
}

void SelectedPiece::Working()
{
    if (IsSelected()) {
    DrawCube(current->position, 1.0f, 1.0f, 1.0f, Settings::Colors[1]);
    }


}

void SelectedPiece::Unselect()
{
    selected = false;
}

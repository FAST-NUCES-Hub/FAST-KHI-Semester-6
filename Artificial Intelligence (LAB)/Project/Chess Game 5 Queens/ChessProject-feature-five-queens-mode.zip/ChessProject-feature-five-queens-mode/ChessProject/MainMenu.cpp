#pragma once
#include "MainMenu.h"


MainMenu::MainMenu(vector<Rectangle> button, vector <string> Labels): Buttons(button) , Labels(Labels) {}

void MainMenu::DrawButtons()
{
	for (auto a : Buttons) {
		DrawButton(a, DARKGRAY);
	}
}

void MainMenu::Update(GameState& para )
{
	BeginDrawing();
	ClearBackground(WHITE);
	DrawButtons();
	DrawLabels(10,BLACK,30);
	Action(CollisionChecker(RED,BLACK,10,30),para);
	EndDrawing();
}

int MainMenu::CollisionChecker(Color HighlightColour,Color TextColour,int offset,int fontsize)
{
	for (int i = 0; i < Buttons.size();i++) {
		if (CheckCollisionPointRec(GetMousePosition(), Buttons[i]))
		{
			DrawButton(Buttons[i], HighlightColour);
			DrawLabel(Labels[i], Vector2{ Buttons[i].x,Buttons[i].y }, TextColour, offset, fontsize);
			if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
				return i;
			}
		}


	}
	return -1;
}

void MainMenu::DrawLabels(int offset,Color colour,int fontsize)
{
	for (int i = 0; i < Buttons.size();i++) {
		DrawLabel(Labels[i], Vector2{ Buttons[i].x,Buttons[i].y }, colour, offset, fontsize);
	}
}

void MainMenu::Action(int query,GameState& para)
{
	if (query != -1) {
		switch (query)
		{
		case 0:
			para = GameScreen;
			break;
		case 1:
			para = SettingsScreen;
			break;
		case 2:
			exit(0);
			break;
		default:
			break;
		}
	}
}

void MainMenu::DrawButton(Rectangle button, Color colour)
{
	DrawRectangleRec(button, colour);
}

void MainMenu::DrawLabel(string label,Vector2 pos ,Color colour,int offset,int fontsize)
{
	DrawText(label.c_str(), pos.x, pos.y + offset,fontsize,colour);
}



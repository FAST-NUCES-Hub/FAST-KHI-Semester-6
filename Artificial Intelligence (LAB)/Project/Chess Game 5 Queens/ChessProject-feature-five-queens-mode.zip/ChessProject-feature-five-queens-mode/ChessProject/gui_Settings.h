/*******************************************************************************************
*
*   Menu v1.0.0 - This is the Layout For the Main Menu Of The Game
*
*   MODULE USAGE:
*       #define GUI_MENU_IMPLEMENTATION
*       #include "gui_Menu.h"
*
*       INIT: GuiMenuState state = InitGuiMenu();
*       DRAW: GuiMenu(&state);
*
*   LICENSE: Propietary License
*
*   Copyright (c) 2022 ChessProject. All Rights Reserved.
*
*   Unauthorized copying of this file, via any medium is strictly prohibited
*   This project is proprietary and confidential unless the owner allows
*   usage in any other form by expresely written permission.
*
**********************************************************************************************/

#include "raylib.h"

// WARNING: raygui implementation is expected to be defined before including this header
#undef RAYGUI_IMPLEMENTATION
#include "raygui.h"

#include <string.h>     // Required for: strcpy()

#ifndef GUI_MENU_H
#define GUI_MENU_H

typedef struct {
    // Define anchors
    Vector2 anchor01;            // ANCHOR ID:1
    
    // Define controls variables
    bool WindowBox000Active;            // WindowBox: WindowBox000
    float SliderBar001Value;            // SliderBar: SliderBar001
    Color ColorPickerValue;            // ColorPicker: ColorPicker
    int ComboBox003Active;            // ComboBox: ComboBox003
    float Slider004Value;            // Slider: Slider004
    bool DropdownBox005EditMode;
    int DropdownBox005Active;            // DropdownBox: DropdownBox005
    int ComboBox007Active;            // ComboBox: ComboBox007
    bool CheckBoxEx009Checked;            // CheckBoxEx: CheckBoxEx009

    // Define rectangles
    Rectangle layoutRecs[11];

    // Custom state variables (depend on development software)
    // NOTE: This variables should be added manually if required

} GuiMenuState;

#ifdef __cplusplus
extern "C" {            // Prevents name mangling of functions
#endif

//----------------------------------------------------------------------------------
// Defines and Macros
//----------------------------------------------------------------------------------
//...

//----------------------------------------------------------------------------------
// Types and Structures Definition
//----------------------------------------------------------------------------------
// ...

//----------------------------------------------------------------------------------
// Module Functions Declaration
//----------------------------------------------------------------------------------
GuiMenuState InitGuiMenu(void);
void GuiMenu(GuiMenuState *state);
static void LabelButton008();                // LabelButton: LabelButton008 logic
static void Button010();                // Button: Button010 logic

#ifdef __cplusplus
}
#endif

#endif // GUI_MENU_H

/***********************************************************************************
*
*   GUI_MENU IMPLEMENTATION
*
************************************************************************************/
#if defined(GUI_MENU_IMPLEMENTATION)

#include "raygui.h"

//----------------------------------------------------------------------------------
// Global Variables Definition
//----------------------------------------------------------------------------------
//...

//----------------------------------------------------------------------------------
// Internal Module Functions Definition
//----------------------------------------------------------------------------------
//...

//----------------------------------------------------------------------------------
// Module Functions Definition
//----------------------------------------------------------------------------------
GuiMenuState InitGuiMenu(void)
{
    GuiMenuState state = { 0 };

    // Init anchors
    state.anchor01 = (Vector2){ 560, 216 };            // ANCHOR ID:1
    
    // Initilize controls variables
    state.WindowBox000Active = true;            // WindowBox: WindowBox000
    state.SliderBar001Value = 0.0f;            // SliderBar: SliderBar001
    state.ColorPickerValue = (Color){ 0, 0, 0, 0 };            // ColorPicker: ColorPicker
    state.ComboBox003Active = 0;            // ComboBox: ComboBox003
    state.Slider004Value = 0.0f;            // Slider: Slider004
    state.DropdownBox005EditMode = false;
    state.DropdownBox005Active = 0;            // DropdownBox: DropdownBox005
    state.ComboBox007Active = 0;            // ComboBox: ComboBox007
    state.CheckBoxEx009Checked = false;            // CheckBoxEx: CheckBoxEx009

    // Init controls rectangles
    state.layoutRecs[0] = (Rectangle){ state.anchor01.x + 40, state.anchor01.y + 0, 640, 504 };// WindowBox: WindowBox000
    state.layoutRecs[1] = (Rectangle){ state.anchor01.x + 136, state.anchor01.y + 48, 120, 24 };// SliderBar: SliderBar001
    state.layoutRecs[2] = (Rectangle){ state.anchor01.x + 544, state.anchor01.y + 48, 96, 96 };// ColorPicker: ColorPicker
    state.layoutRecs[3] = (Rectangle){ state.anchor01.x + 344, state.anchor01.y + 48, 184, 24 };// ComboBox: ComboBox003
    state.layoutRecs[4] = (Rectangle){ state.anchor01.x + 136, state.anchor01.y + 96, 120, 16 };// Slider: Slider004
    state.layoutRecs[5] = (Rectangle){ state.anchor01.x + 136, state.anchor01.y + 144, 120, 24 };// DropdownBox: DropdownBox005
    state.layoutRecs[6] = (Rectangle){ state.anchor01.x + 48, state.anchor01.y + 144, 80, 24 };// Label: Label006
    state.layoutRecs[7] = (Rectangle){ state.anchor01.x + 344, state.anchor01.y + 224, 184, 24 };// ComboBox: ComboBox007
    state.layoutRecs[8] = (Rectangle){ state.anchor01.x + 368, state.anchor01.y + 192, 120, 24 };// LabelButton: LabelButton008
    state.layoutRecs[9] = (Rectangle){ state.anchor01.x + 504, state.anchor01.y + 192, 24, 24 };// CheckBoxEx: CheckBoxEx009
    state.layoutRecs[10] = (Rectangle){ state.anchor01.x + 344, state.anchor01.y + 264, 184, 24 };// Button: Button010

    // Custom variables initialization

    return state;
}
// LabelButton: LabelButton008 logic
static void LabelButton008()
{
    // TODO: Implement control logic
}
// Button: Button010 logic
static void Button010()
{
    // TODO: Implement control logic
}


void GuiMenu(GuiMenuState *state)
{
    // Const text
    const char *WindowBox000Text = "SAMPLE TEXT";    // WINDOWBOX: WindowBox000
    const char *SliderBar001Text = "#122#";    // SLIDERBAR: SliderBar001
    const char *ComboBox003Text = "ChessBoard Colour1;ChessBoard Colour2;Highlight Colour;Selected Colour;LegalMovesColour;CurrentSelectedColour";    // COMBOBOX: ComboBox003
    const char *Slider004Text = "Scale of Models:";    // SLIDER: Slider004
    const char *DropdownBox005Text = "Theme1;Theme2;Theme3;Theme4";    // DROPDOWNBOX: DropdownBox005
    const char *Label006Text = "Themes:";    // LABEL: Label006
    const char *ComboBox007Text = "Load Custom Models";    // COMBOBOX: ComboBox007
    const char *LabelButton008Text = "Custom Models:";    // LABELBUTTON: LabelButton008
    const char *CheckBoxEx009Text = "";    // CHECKBOXEX: CheckBoxEx009
    const char *Button010Text = "Select File";    // BUTTON: Button010
    
    // Draw controls
    if (state->DropdownBox005EditMode) GuiLock();

    if (state->WindowBox000Active)
    {
        state->WindowBox000Active = !GuiWindowBox(state->layoutRecs[0], WindowBox000Text);
        GuiSliderBar(state->layoutRecs[1], SliderBar001Text, NULL, &state->SliderBar001Value, 0, 100);
        GuiColorPicker(state->layoutRecs[2], ColorPickerText, &state->ColorPickerValue);
        GuiComboBox(state->layoutRecs[3], ComboBox003Text, &state->ComboBox003Active);
        GuiSlider(state->layoutRecs[4], Slider004Text, NULL, &state->Slider004Value, 0, 100);
        GuiLabel(state->layoutRecs[6], Label006Text);
        GuiComboBox(state->layoutRecs[7], ComboBox007Text, &state->ComboBox007Active);
        if (GuiLabelButton(state->layoutRecs[8], LabelButton008Text)) LabelButton008();
        GuiCheckBox(state->layoutRecs[9], CheckBoxEx009Text, &state->CheckBoxEx009Checked);
        if (GuiButton(state->layoutRecs[10], Button010Text)) Button010(); 
        if (GuiDropdownBox(state->layoutRecs[5], DropdownBox005Text, &state->DropdownBox005Active, state->DropdownBox005EditMode)) state->DropdownBox005EditMode = !state->DropdownBox005EditMode;
    }
    
    GuiUnlock();
}

#endif // GUI_MENU_IMPLEMENTATION

# Chess Project

A modern 3D chess game built with C++ and Raylib, featuring an integrated Stockfish AI engine, customizable 3D chess pieces, and multiple UI themes.

## Features

### 🎮 Core Gameplay
- **Full 3D Chess Experience** - Interactive 3D chessboard with realistic piece models
- **Legal Move Validation** - Built-in move validation system
- **Multiple AI Engines** - Play against Stockfish or the custom built-in Minimax engine
- **Engine Selection UI** - Easily switch between different AI opponents
- **AI Auto-Play** - Watch AI vs AI matches
- **Five Queens Mode** - Play a unique variation with two queens per side and one random extra queen
- **Win Detection** - Automatic game outcome detection

### 🎨 Customization
- **Custom Chess Pieces** - Load your own 3D models (.glb format)
- **Multiple UI Themes** - 7 built-in themes:
  - Default
  - Ashes
  - Bluish
  - Candy
  - Cherry
  - Cyber
  - Dark
- **Configurable Board Colors** - Customize board appearance

### 📷 Camera & Controls
- **Free Camera Movement** - Navigate around the board with right-click drag
- **Adjustable View Angles** - Full 3D perspective control
- **FPS Display** - Monitor performance in real-time

## Prerequisites

### Required Dependencies
- **Visual Studio** (2017 or later recommended)
- **Raylib** - Graphics library
- **Stockfish Engine** - Chess AI engine
- **subprocess.h** - Process management library for Windows

### Chess Models
The application requires 3D models for chess pieces in `.glb` format. Place them in `ChessProject/Resources/ChessSet/`:
- `LightKing.glb` / `DarkKing.glb`
- `LightQueen.glb` / `DarkQueen.glb`
- `LightBishop.glb` / `DarkBishop.glb`
- `LightTower.glb` / `DarkTower.glb`
- `LightKnight.glb` / `DarkKnight.glb`
- `LightPawn.glb` / `DarkPawn.glb`

> **Note:** Chess piece models are not included in this repository to reduce size. You'll need to provide your own 3D models.

## Installation

### 1. Clone the Repository
```bash
git clone https://github.com/yourusername/ChessProject.git
cd ChessProject
```

### 2. Install Dependencies

#### Raylib
Follow the [Raylib installation guide](https://www.raylib.com/) for Visual Studio integration.

#### Stockfish
1. Download Stockfish from [stockfishchess.org](https://stockfishchess.org/download/)
2. Extract the Stockfish executable to `stockfish/stockfish.exe` (relative to your project executable)
   - Alternatively, extract to any location and configure the path in Settings
3. The default path is `stockfish/stockfish.exe`, but you can customize it through the Settings system

#### subprocess.h
This library should be included in your Visual Studio C++ environment or can be found at [sheredom/subprocess.h](https://github.com/sheredom/subprocess.h)

### 3. Add Chess Models
Place your `.glb` chess piece models in `ChessProject/Resources/ChessSet/`

### 4. Build the Project
1. Open `ChessProject.sln` in Visual Studio
2. Set build configuration to **x64**
3. Build the solution (Ctrl+Shift+B)
4. Run the project (F5)

## Project Structure

```
ChessProject/
├── ChessProject/
│   ├── Board.cpp/h              # Chess board logic
│   ├── ChessPiece.cpp/h         # Chess piece representation
│   ├── Spot.cpp/h               # Board square/spot logic
│   ├── SelectedPiece.cpp/h      # Selected piece handling
│   ├── Stockfish.cpp/h          # Stockfish AI integration
│   ├── MainMenu.cpp/h           # Main menu implementation
│   ├── Settings.h               # Settings management
│   ├── gui_Settings.h           # Settings GUI
│   ├── gui_window_file_dialog.h # File dialog for custom models
│   ├── ChessProject.cpp         # Main entry point
│   ├── Resources/
│   │   ├── ChessSet/            # 3D chess piece models (gitignored)
│   │   └── GUI/                 # GUI layouts and options
│   └── styles/                  # UI theme styles
└── README.md                    # This file
```

## Usage

### Starting the Game
1. Launch the application
2. From the main menu, select:
   - **New Game** - Start a new chess game
   - **Settings** - Customize colors, themes, and chess pieces
   - **Exit** - Close the application

### Controls
- **Mouse Movement** - Hover over pieces to select
- **Left Click** - Select piece / Make move
- **Right Click (Hold)** - Free camera mode
- **ESC** - Return to main menu

### Customizing Chess Pieces
1. Go to **Settings** from the main menu
2. Select a piece type from the list
3. Browse for your custom `.glb` model file
4. The game will reload the chessboard with your new model

### Changing Themes
1. Go to **Settings**
2. Select a theme from the available options
3. The UI will update immediately

## Configuration

Settings are automatically saved in `Settings.bin` (gitignored) including:
- Board colors
- Chess piece model paths
- UI theme selection
- Stockfish engine executable path

To reset to defaults, simply delete `Settings.bin` and restart the application.

## Technical Details

### Architecture
- **Resolution:** 1920x1080 (resizable window)
- **Target FPS:** 60
- **3D Rendering:** Raylib with custom camera system
- **GUI:** raygui with custom layouts
- **AI Engines:** Stockfish (external process communication) and built-in MinimaxEngine

### Key Classes
- **Board** - Manages the 8x8 chess board and game state
- **ChessPiece** - Represents individual chess pieces
- **Spot** - Individual squares on the board
- **SelectedPiece** - Handles piece selection and highlighting
- **Stockfish** - Manages communication with Stockfish engine
- **MinimaxEngine** - Built-in custom chess AI using minimax algorithm
- **Settings** - Persistent configuration management

## Known Limitations

1. **Screen Resolution** - Optimized for 1920x1080 displays
2. **Model Format** - Only supports `.glb` 3D model format
3. **Platform** - Currently Windows-only (Visual Studio project)

## Future Enhancements
- [ ] Multiplayer support (local/network)
- [ ] Move history and game replay
- [ ] Save/load game states
- [ ] Move hints and tutorials
- [ ] Cross-platform support (Linux, macOS)
- [ ] Additional 3D model format support

## Contributing

Contributions are welcome! Please feel free to submit pull requests or open issues for bugs and feature requests.

### Development Setup
1. Follow the installation instructions above
2. Make your changes in a feature branch
3. Test thoroughly
4. Submit a pull request with a clear description


## Acknowledgments

- **Raylib** - Amazing graphics library for C/C++
- **Stockfish** - Powerful open-source chess engine
- **raygui** - Immediate mode GUI library




**Enjoy playing chess! ♟️**
